<?php $__env->startSection('head'); ?>
    <title>Settings | fabits.in</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div id="ajax-title" class="hidden-xs-up" data-title="Settings | fabits.in"></div>

    <div class="container-fluid pt-5">
        <div class="row ">
            <div class="offset-lg-1 col-lg-8 col-md-12 sd-1 b-white  ba-1 px-0  ">
                <div class="col-md-3 px-0 br-1 border-light h-100 pb-3 text-xs-center b-white z-11 " id="settings-list">

                    <img class="img-fluid m-1  pp-100 rounded-circle "
                         src="<?php echo e(Cloudder::show($sentinel_user->profile_picture_small, array())); ?>"
                         alt="<?php echo e($sentinel_user->name); ?>">

                    <div class="list-group  ">
                        <a href="/settings/account" data-loc="settings"
                           class="list-group-item   pl-1 bx-0 square-corner list-group-item-action">
                            Account
                        </a>

                        <a href="/settings/info" data-loc="settings"
                           class="list-group-item  pl-1  bx-0 square-corner list-group-item-action">
                            User Info.
                        </a>

                        <a href="/settings/phone" data-loc="settings"
                           class="list-group-item  pl-1 bx-0  square-corner list-group-item-action">
                            Phone
                        </a>

                        <a href="/settings/password" data-loc="settings"
                           class="list-group-item  pl-1 bx-0 square-corner list-group-item-action">
                            Password
                        </a>
                        <a href="/settings/privacy" data-loc="settings"
                           class="list-group-item  pl-1 bx-0 square-corner list-group-item-action">
                            Privacy
                        </a>

                        <a href="/settings/notification" data-loc="settings"
                           class="list-group-item  pl-1 bx-0 square-corner list-group-item-action">
                            Alerts
                        </a>

                        <a href="/settings/blocked" data-loc="settings"
                           class="list-group-item  pl-1 bx-0 square-corner list-group-item-action">
                            Blocked Users
                        </a>


                    </div>

                </div>
                <div class="col-md-9  pl-1 b-white h-100 col-xs-12 z-10 " style="position:absolute; top:0; right:0;">
                    <a href="#" data-loc="settings-back" class="hidden-md-up ">
                        <i class="fa fa-lg fa-arrow-left mt-1" aria-hidden="true"></i>
                    </a>
                    <div id="settings-content">

                        <?php if($pageid == 'account'): ?>
                            <?php echo $__env->make('settings.account', array(
                            'email'=>$email,
                            'facebook'=>$facebook,
                            'whatsapp'=>$whatsapp,
                            ), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($pageid == 'info'): ?>
                            <?php echo $__env->make('settings.info', array(
                            'intro'=>$intro,
                            'location'=>$location,
                            'relationship'=>$relationship
                            ), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($pageid == 'phone'): ?>
                            <?php echo $__env->make('settings.phone', array(
                            'phone'=>$phone,
                            ), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($pageid == 'password'): ?>
                            <?php echo $__env->make('settings.password', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($pageid == 'privacy'): ?>
                            <?php echo $__env->make('settings.privacy', array(
                            'privacy'=>$privacy,
                            ), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($pageid == 'notification'): ?>
                            <?php echo $__env->make('settings.notification', array(
                            'notification'=>$notification,
                            ), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($pageid == 'blocked'): ?>
                            <?php echo $__env->make('settings.blocked', array(
                            'blocks'=>$blocks,
                            ), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php else: ?>
                            <?php echo $__env->make('settings.account', array(
                            'email'=>$email,
                            'facebook'=>$facebook,
                            'whatsapp'=>$whatsapp,
                            ), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endif; ?>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="otpModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel">Enter OTP</h4>
                </div>
                <?php echo e(Form::open(array('url' => '/phoneOTP', 'method' => 'POST'))); ?>

                <div class="modal-body">
                    <?php echo e(Form::hidden('success', 'otp2')); ?>

                    <div class="form-group pt-1">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-lock" aria-hidden="true"></i>
                            </div>
                            <?php echo e(Form::text('otp' , '', array('class' => 'form-control','placeholder'=>'4 digit  OTP','required') )); ?>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <?php echo e(Form::submit('Confirm',array('class' => 'btn btn-primary'))); ?>

                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>

    <script type="text/javascript">

        <?php if(!$ajax): ?>
                window.onload = function () {
            <?php endif; ?>
                $(document).ready(function () {
                $('#floatPostButton').hide();
            });
            <?php if(!$ajax): ?>
        };
        <?php endif; ?>
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make($ajax ? 'home.blank' :'home.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>