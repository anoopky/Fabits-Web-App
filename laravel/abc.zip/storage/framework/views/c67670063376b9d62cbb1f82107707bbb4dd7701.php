<?php $__env->startSection('head'); ?>
    <title>Search | fabits.in</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div id="ajax-title" class="hidden-xs-up" data-title="Search | fabits.in"></div>
    <div class="container-fluid pt-5">

        <div class="row">

            <div class=" offset-lg-1 col-lg-8 col-md-12  px-0">
                <div id="search" class="grid2">
                    <div class="gutter-sizer"></div>
                    <div class="grid-item1"></div>

                    <?php if(count($searchs)>0): ?>
                <?php $__currentLoopData = $searchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="card grid-item1 square-corner sd-min ">
                            <div class="container-fluid">
                                <div class="row px-0_5 my-1">
                                    <ul class="nav text-xs-center">
                                        <li class="nav-item align-top">
                                            <a class="" href="<?php echo e('/@'.$search["username"]); ?>" data-loc="page">
                                                <img class="rounded-circle pp-100" src="<?php echo e($search["image"]); ?>"
                                                     alt="<?php echo e($search["name"]); ?>">
                                            </a></li>
                                        <li class="nav-item mx-0 ">
                                            <div class="lh-1 pl-0_5 ">
                                                <p class="p-0 m-0 post_user_link opensanN">
                                                    <a class="" href="<?php echo e('/@'.$search["username"]); ?>" data-loc="page">
                                                        <?php echo e($search["name"]); ?></a></p>
                                                <small class="text-muted"> <?php echo e('@'.$search["username"]); ?></small>
                                                <br>
                                                <small class="text-muted"> Followers <?php echo e($search["followers"]); ?> . Profile
                                                    views <?php echo e($search["profileviews"]); ?> .
                                                    FaceMatch <?php echo e($search["facematch"]); ?></small>
                                            </div>
                                        </li>
                                        <li class="nav-item px-0 mx-0 ">
                                            <?php echo e(Form::open(array('url' => '/follow', 'method' => 'POST', 'class' => 'd-inline form-inline'))); ?>

                                            <?php echo e(Form::hidden('success', 'follow')); ?>

                                            <?php echo e(Form::hidden('user_id', $search["id"] )); ?>


                                            <?php if($search["isfollow"]): ?>

                                                <button type="submit" class="nav-link btn btn-secondary unfollow m-1 ">
                                                    <i class="fa fa-user-plus  " aria-hidden="true"></i> Following
                                                </button>
                                            <?php else: ?>
                                                <button type="submit" class="nav-link btn btn-primary m-1">
                                                    <i class="fa fa-user-plus  " aria-hidden="true"></i> Follow
                                                </button>
                                            <?php endif; ?>
                                            <?php echo e(Form::close()); ?>


                                            <?php echo e(Form::open(array('url' => '/conversation', 'method' => 'POST', 'class' => 'd-inline form-inline'))); ?>

                                            <?php echo e(Form::hidden('success', 'chat')); ?>

                                            <?php echo e(Form::hidden('user_id', $search["id"] )); ?>

                                            <button type="submit" class="nav-link btn btn-outline-secondary m-1 ">
                                                <i class="fa fa-comments " aria-hidden="true"></i> Message
                                            </button>
                                            <?php echo e(Form::close()); ?>

                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php else: ?>
                        <h1 class="text-xs-center hidden-xs-up">NO Result Found!</h1>

                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>


    <script type="text/javascript">

        <?php if(!$ajax): ?>
                window.onload = function () {
            <?php endif; ?>
                $(document).ready(function () {

                var pathname = window.location.href;
                pathname = pathname.substring(pathname.lastIndexOf("/")+1, pathname.length);

                if(pathname.substring(0, 2) == '!#'){

                    var search = encodeURIComponent(pathname);
                    var isData =0;
                    $.getJSON(search, function (data) {

                        $.each(data, function (key, val) {
                            isData =1;
                            var $elems = $(postTemplate(val));
                            $('.grid2').append($elems).masonry('appended', $elems);

                        });

                    }).done(function () {

                        if(isData ==1) {
                            commentInit();

                        }
                        else{
                            $('h1').removeClass('hidden-xs-up');

                        }



                    });
                }
                else{

                    $('h1').removeClass('hidden-xs-up');

                }

                $('#floatPostButton').show();
                $('.grid2').masonry({
                    percentPosition: true,
                    gutter: '.gutter-sizer',
                    itemSelector: '.grid-item1',
                    columnWidth: 80,
                });
            });
            <?php if(!$ajax): ?>
        };
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($ajax ? 'home.blank' :'home.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>