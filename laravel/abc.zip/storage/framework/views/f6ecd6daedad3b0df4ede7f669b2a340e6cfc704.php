<div class="row m-0">
    <div class=" offset-lg-1 col-lg-8 col-md-12 p-0 profile-wall"
         style="background:  url('<?php echo e(Cloudder::show($userprofile->wall_picture_big, array())); ?>');background-size:cover;">
        <div class="p-0 profile-image-cover">

        </div>
        <div class="jumbotron p-0 pb-1 mb-0 profile-jumbo">
            <div class="container-fluid">
                <div class="row p-0 profile-row">

                    <div class="col-xs-12  text-xs-center lh-1">
                        <?php if($sentinel_user->username == $userprofile->username): ?>
                        <i class="fa fa-camera fa-lg cursor-pointer profile-wall-change" data-toggle="modal" data-target="#wallModal" aria-hidden="true"></i>
                        <?php endif; ?>
                        <img src="<?php echo e(Cloudder::show($userprofile->profile_picture_big, array())); ?>"
                             class="rounded-circle pp-150 sd-1 myprofile"
                             alt="<?php echo e($userprofile->name); ?>">
                            <?php if($sentinel_user->username == $userprofile->username): ?>
                        <i class="fa fa-camera fa-lg cursor-pointer profile-pic-change" data-toggle="modal" data-target="#profilepicModal" aria-hidden="true"></i>
                            <?php endif; ?>
                        <p class="lead mt-1 opensanL"><b><?php echo e($userprofile->name); ?></b></p>
                        <p><?php echo e($profiledata["college"]); ?> - <?php echo e($profiledata["branch"]); ?> - <?php echo e($profiledata["year"]); ?></p>
                        <p class="breakit"><?php echo e($userprofile->intro); ?>

                            <?php if($sentinel_user->username == $userprofile->username): ?>
                                <span><a href="/settings/info" class="white" data-loc="page-full"> <i class="fa fa-pencil fa-lg cursor-pointer" aria-hidden="true"></i></a></span>
                            <?php endif; ?>
                        </p>
                    </div>

                    <nav class="nav nav-inline ml-1 mt-0 mb-2  text-xs-center   ">
                        <?php if($sentinel_user->username != $userprofile->username): ?>
                            <?php echo e(Form::open(array('url' => '/follow', 'method' => 'POST', 'class' => 'd-inline form-inline'))); ?>

                            <?php echo e(Form::hidden('success', 'follow')); ?>

                            <?php echo e(Form::hidden('user_id', $userprofile->id )); ?>


                            <?php if($profiledata["isfollow"]): ?>

                                <button type="submit" class="nav-link btn btn-secondary unfollow ">
                                    <i class="fa fa-user-plus  " aria-hidden="true"></i> Following
                                </button>
                            <?php else: ?>
                                <button type="submit" class="nav-link btn btn-primary   ">
                                    <i class="fa fa-user-plus  " aria-hidden="true"></i> Follow
                                </button>
                            <?php endif; ?>
                            <?php echo e(Form::close()); ?>


                            <?php echo e(Form::open(array('url' => '/conversation', 'method' => 'POST', 'class' => 'd-inline form-inline'))); ?>

                            <?php echo e(Form::hidden('success', 'chat')); ?>

                            <?php echo e(Form::hidden('user_id', $userprofile->id )); ?>


                            <div class="btn-group" role="group">
                                <button  class="nav-link btn btn-secondary   dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-comments " aria-hidden="true"></i> Message
                                </button>
                                <div class="dropdown-menu " aria-labelledby="btnGroupDrop1">
                                    <button class="dropdown-item" type="submit" value="true" name="chat_n" id="chat-n">Chat</button>
                                    <button class="dropdown-item" type="submit" value="false" name="chat_a" id="chat-a">Anonymous Chat</button>
                                </div>
                            </div>

                            <?php echo e(Form::close()); ?>


                            <?php echo e(Form::open(array('url' => '/block', 'method' => 'POST', 'class' => 'd-inline form-inline'))); ?>

                            <?php echo e(Form::hidden('success', 'block')); ?>

                            <?php echo e(Form::hidden('user_id', $userprofile->id )); ?>

                            <div class="btn-group" role="group">
                                <button  class="nav-link btn btn-secondary   dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    More
                                </button>
                                <div class="dropdown-menu " aria-labelledby="btnGroupDrop1">
                                    <button class="dropdown-item" type="submit" value="true" name="chat_n" id="chat-n">
                                        <?php if($profiledata["isblock"] > 0 ): ?>
                                        <i class="fa fa-ban" aria-hidden="true"></i> Unblock
                                        <?php else: ?>
                                        <i class="fa fa-ban" aria-hidden="true"></i> Block
                                        <?php endif; ?>
                                    </button>
                                </div>
                            </div>
                            <?php echo e(Form::close()); ?>



                        <?php else: ?>
                            <a href="/settings" data-loc="page" class="nav-link btn btn-secondary">
                                <i class="fa fa-cog " aria-hidden="true"></i> Setting
                            </a>

                        <?php endif; ?>
                    </nav>
                    <nav class="nav nav-inline ml-0 user-stats text-xs-center ">
                        <?php echo e(Form::open(array('url' => '/followers', 'method' => 'POST', 'class' => 'd-inline form-inline'))); ?>

                        <?php echo e(Form::hidden('success', 'followers')); ?>

                        <?php echo e(Form::hidden('user_id', $userprofile->id )); ?>

                        <a class=" nav-link ml-1 px-1" href="#"  onclick="$(this).submit();">
                            <p class="h2 text-primary opensanL" id="user_followers">
                                <i class="fa fa-users " aria-hidden="true"></i> <?php echo e($profiledata["followers"]); ?></p>
                            <p class="lead opensanL">Followers</p>
                        </a>
                        <?php echo e(Form::close()); ?>


                        <?php echo e(Form::open(array('url' => '/following', 'method' => 'POST', 'class' => 'd-inline form-inline'))); ?>

                        <?php echo e(Form::hidden('success', 'following')); ?>

                        <?php echo e(Form::hidden('user_id', $userprofile->id )); ?>

                        <a class="nav-link  px-1" href="#" onclick="$(this).submit();">
                            <p class="h2  pumpkin opensanL" id="user_following">
                                <i class="fa fa-user " aria-hidden="true"></i> <?php echo e($profiledata["following"]); ?></p>
                            <p class="lead opensanL">Following</p></a>
                        <?php echo e(Form::close()); ?>

                        <a class="nav-link  px-1" href="#">
                            <p class="h2 text-muted opensanL" id="user_views">
                                <i class="fa fa-user-secret" aria-hidden="true"></i> <?php echo e($profiledata["profile_views"]); ?>

                            </p>
                            <p class="lead">Profile views</p></a>

                        <a class="nav-link px-1" href="#">
                            <p class="h2 neptritius opensanL" id="user_posts">
                                <i class="fa fa-pencil" aria-hidden="true"></i> <?php echo e($profiledata["posts"]); ?></p>
                            <p class="lead">Posts</p></a>

                        <?php echo e(Form::open(array('url' => '/facematches', 'method' => 'POST', 'class' => 'd-inline form-inline'))); ?>

                        <?php echo e(Form::hidden('success', 'facematches')); ?>

                        <?php echo e(Form::hidden('user_id', $userprofile->id )); ?>

                        <a class="nav-link px-1" href="#" onclick="$(this).submit();">
                            <p class="h2  pomegrnate opensanL" id="user_facematch">
                                <i class="fa fa-heart" aria-hidden="true"></i> <?php echo e($profiledata["faceMatch_Rating"]); ?>

                            </p>
                            <p class="lead opensanL">FaceMatch Rating</p></a>
                        <?php echo e(Form::close()); ?>


                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row m-0">
    <div class="offset-lg-1 col-lg-8 col-md-12 p-0 mb-0 bt-0 profile-user-info ">

        <div class="col-md-3 br-1  bb-1  border-light">

            <div class="row m-0">

                <div class="col-xs-12 text-xs-center p-1 opensanN">
                    <i class="fa fa-2x fa-map-marker" aria-hidden="true"></i>
                    <p class="lead"> <?php echo e($userprofile["hometown"]); ?></p>
                </div>
            </div>
        </div>


        <div class="col-md-3 br-1  bb-1  border-light">

            <div class="row m-0">

                <div class="col-xs-12 text-xs-center p-1 opensanN">
                    <i class="fa fa-2x fa-phone" aria-hidden="true"></i>

                    <p class="lead">

                        <?php if($userprofile["phone"] == null): ?>
                            -
                            <?php else: ?>
                            <?php if($Privacy["phone"] == "0"): ?>

                                <?php if($sentinel_user->username != $userprofile->username): ?>
                                <i class="fa fa-lock fa-lg" aria-hidden="true"></i>
                                <?php else: ?>
                                <?php echo e($userprofile["phone"]); ?>

                            <?php endif; ?>

                            <?php elseif($Privacy["phone"] == 1): ?>

                                <?php echo e($userprofile["phone"]); ?>



                      <?php else: ?>
                          -
                        <?php endif; ?>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>


        <div class="col-md-3 br-1  bb-1  border-light">

            <div class="row m-0">

                <div class="col-xs-12 text-xs-center p-1 opensanN">
                    <i class="fa fa-2x fa-heart" aria-hidden="true"></i>
                    <p class="lead"> <?php echo e($userprofile["relationship"]["name"]); ?></p>
                </div>
            </div>
        </div>


        <div class="col-md-3 br-1  bb-1  border-light">

            <div class="row m-0">
                <div class="col-xs-12 text-xs-center p-1 opensanN">
                    <i class="fa fa-2x fa-birthday-cake" aria-hidden="true"></i>
                    <p class="lead"> <?php echo e($dob); ?> </p>
                </div>
            </div>
        </div>


    </div>
</div>