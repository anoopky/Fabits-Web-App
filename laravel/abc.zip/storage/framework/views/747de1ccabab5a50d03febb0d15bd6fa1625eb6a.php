<?php echo $__env->yieldContent('body'); ?>
<script>chat_app_conversation_id =null;</script>