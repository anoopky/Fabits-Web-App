<div class="pt-1">

    <h5 class="text-xs-center">You have been blocked by <span class="tag tag-danger tag-pill" ><?php echo e($blockme); ?></span> people.</h5>
    <?php $__currentLoopData = $blocksChat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo e(Form::open(array('url' => '/settings/blockedChat', 'method' => 'POST'))); ?>

        <div class="col-xs-12 bb-1 border-light pt-0_5">
            <div class="container-fluid">
                <div class="row pb-0_5  px-0_5 ">
                    <ul class="nav  nav-inline ">
                        <li class="nav-item align-top ">
                            <a class="" href="/<?php echo e('@'.$block["username"]); ?>">
                                <img class="rounded-circle pp-60" src=" <?php echo e(Cloudder::show($block["picture"], array())); ?> " alt="<?php echo e($block["name"]); ?>">
                            </a></li>
                        <li class="nav-item mx-0 comment_width">
                            <div class="lh-1 pl-0_5 pt-0_5 ">
                                <p class="m-0 p-0 setting_link opensanN">
                                    <a class="" href="/<?php echo e('@'.$block["username"]); ?>"> <?php echo e($block["name"]); ?>

                                        <span class="tag tag-danger tag-pill">Chat</span></a></p>

                                <small class="text-muted pt-1 opensanN"><?php echo e($block["college"]); ?> - <?php echo e($block["branch"]); ?> - <?php echo e($block["year"]); ?>  </small>
                            </div>
                        </li>
                        <li class="nav-item float-xs-right  pt-1">
                            <?php echo e(Form::hidden('id', $block["id"])); ?>

                            <?php echo e(Form::hidden('success', 'unblock')); ?>


                            <button type="submit" class="close">
                                <span aria-hidden="true">&times;</span>
                            </button>

                        </li>
                    </ul>
                </div>
            </div>

        </div>
        <?php echo e(Form::close()); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo e(Form::open(array('url' => '/settings/blocked', 'method' => 'POST'))); ?>

        <div class="col-xs-12 bb-1 border-light pt-0_5">
            <div class="container-fluid">
                <div class="row pb-0_5  px-0_5 ">
                    <ul class="nav  nav-inline ">
                        <li class="nav-item align-top ">
                            <a class="" href="/<?php echo e('@'.$block["username"]); ?>">
                                <img class="rounded-circle pp-60" src=" <?php echo e(Cloudder::show($block["picture"], array())); ?> " alt="<?php echo e($block["name"]); ?>">
                            </a></li>
                        <li class="nav-item mx-0 comment_width">
                            <div class="lh-1 pl-0_5 pt-0_5 ">
                                <p class="m-0 p-0 setting_link opensanN">
                                    <a class="" href="/<?php echo e('@'.$block["username"]); ?>"> <?php echo e($block["name"]); ?>

                                        <span class="tag tag-danger tag-pill">Profile</span></a></p>

                                <small class="text-muted pt-1 opensanN"><?php echo e($block["college"]); ?> - <?php echo e($block["branch"]); ?> - <?php echo e($block["year"]); ?>  </small>
                            </div>
                        </li>
                        <li class="nav-item float-xs-right  pt-1">
                            <?php echo e(Form::hidden('userid', $block["id"])); ?>

                            <?php echo e(Form::hidden('success', 'unblock')); ?>


                            <button type="submit" class="close">
                                <span aria-hidden="true">&times;</span>
                            </button>

                        </li>
                    </ul>
                </div>
            </div>

        </div>
        <?php echo e(Form::close()); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
