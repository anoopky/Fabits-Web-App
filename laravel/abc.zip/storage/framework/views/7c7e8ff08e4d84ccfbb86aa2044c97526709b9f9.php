<?php $__env->startSection('body'); ?>
    <div class="container-fluid pt-5">

        <div class="row">

            <div class=" offset-lg-1 col-lg-8 col-md-12  px-0">

                <div class="card-columns">

                    <div id="posts-custom"></div>
                </div>
            </div>
        </div>
    </div>



    <script type="text/javascript">
        <?php if(!$ajax): ?>
                window.onload = function () {
            <?php endif; ?>

                    $(document).ready(function () {

                $.getJSON("/post/one/<?php echo e($id); ?>", function (data) {
                    // var items = [];
                    $.each(data, function (key, val) {
                        // console.log(key, val);
                        $("#posts-custom").append(postTemplate(val));
                    });

                });
            });
            <?php if(!$ajax): ?>
        };
        <?php endif; ?>
    </script>


<?php $__env->stopSection(); ?>








<?php echo $__env->make($ajax ? 'home.blank' :'home.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>