<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class College_name extends Model
{

    protected $fillable = ['name'];


}
