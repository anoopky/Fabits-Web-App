<?php
namespace App\Http\Controllers;

use App\Block;
use App\Branch;
use App\College_name;
use App\Comment;
use App\Conversation;
use App\Conversationv2;
use App\Events\OnlineConversation;
use App\Events\SeenReadConversation;
use App\Events\TypingV2;
use App\Facematch;
use App\Follow;
use App\GroupList;
use App\Hashtag;
use App\Message;
use App\MessageV2;
use App\Otp;
use App\Post_data;
use App\Profileview;
use App\Relationship;
use App\Reports;
use Illuminate\Http\Request;
use App\oAuth;
use App\Optional;
use App\Privacy;
use App\SMS;
use Cartalyst\Sentinel\Checkpoints\ThrottlingException;
use Cloudder;
use Sentinel;
use Carbon\Carbon;

use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Validator;
use App\Like;
use App\Notification;
use App\Post;
use App\UnfollowPost;
use DB;

class Fabitsapi extends Controller
{


    public function posts(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {


            $postAll = Post::latest()->paginate(5);

            return $this->getPosts($postAll, $user);
        }

        return "-1";
    }

    public function postSingle(Request $request, $token, $postID)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $postAll = Post::where('id', $postID)->get();

            return $this->getPosts($postAll, $user);
        }

        return "-1";
    }


    public function postsControl(Request $request, $token, $operator, $postID)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $op = null;
            if ($operator == "lt")
                $op = "<";
            else
                $op = ">";

            $postAll = Post::where('id', $op, $postID)
                ->latest()
                ->offset(0)
                ->limit(5)
                ->get();

            return $this->getPosts($postAll, $user);
        }

        return "-1";
    }

    public function trend(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {


            $TrendingPosts = Like::groupBy('post_id')
                ->select('post_id', DB::raw('count(post_id) as total'))
                ->where('created_at', '>=', Carbon::now()->subDays(5))
                ->orderby(DB::raw('total'), 'DESC')
                ->get();


            $postID = array();

            foreach ($TrendingPosts as $TrendingPost) {
                array_push($postID, $TrendingPost->post_id);
            }

            $postIDString = implode(",", $postID);

            $postAll = Post::wherein('id', $postID)
                ->orderby(DB::raw("FIELD(id, $postIDString)"))
                ->paginate(5);

            return $this->getPosts($postAll, $user);
        }

        return "-1";
    }

    public function getPosts($postAll, $user)
    {

        $postData = array();

        foreach ($postAll as $key => $value) {
            $post = array();
            $post["post_id"] = $value->id;
            $post["user_id"] = $value->user_id;
            $post["user_name"] = $value->user->name;
            $post["username"] = '@' . $value->user->username;
            $post["user_picture"] = Cloudder::show($value->user->profile_picture_small, array());
            $post["post_text"] = $value->text;
            $carbon = Carbon::parse($value->created_at)->diffForHumans();
            $post["post_time"] = $this->date_small($carbon);
            $post["post_time"] = $this->date_small($carbon);
            $post["likes"] = $value->like->where('like_type', 1)->count();
            $post["dislikes"] = $value->like->where('like_type', 0)->count();
            $post["comments"] = $value->comment->count();
            $post["isliked"] = $value->like->where('like_type', 1)->where('user_id', $user->user_id)->count();
            $post["isdisliked"] = $value->like->where('like_type', 0)->where('user_id', $user->user_id)->count();
            $post["iscommented"] = $value->comment->where('user_id', $user->user_id)->count();

            $post["isfollow"] = UnfollowPost::where('user_id', $user->user_id)
                ->where('post_id', $value->id)->count() ? 0 : Notification::select(['source_id', 'type', 'activity_type', 'created_at'])
                ->where('user_id', $user->user_id)
                ->where('source_id', $value->id)
                ->where('type', 0)
                ->groupby(['source_id', 'type'])
                ->orderby('created_at', 'desc')
                ->count();

            $commentAll = $value->comment()->latest()->offset(0)->limit(1)->get();
            $post["post_comment"] = [];
            $post["post_data"] = [];

            if ($value->type_id >= 2) {

                $postSources = $value->post_data()->get();
                foreach ($postSources as $key1 => $value1) {

                    $postSource = array();
                    if ($value1->type == 4 || $value1->type == 5) {

                        $postSource['source'] = $value1->source;

                    } else {
                        $pieces = explode("-", $value1->source);
                        $postSource['source'] = Cloudder::show($pieces[0], array());
                        $postSource['height'] = $pieces[1];

                    }

                    $postSource['data'] = $value1->data;
                    $postSource['type'] = $value1->type;
                    array_push($post["post_data"], $postSource);

                }


            }
            foreach ($commentAll as $key1 => $value1) {
                $post["post_comment"][0]["post_id"] = $value->id;
                $post["post_comment"][0]["comment_id"] = $value1->id;
                $post["post_comment"][0]["user_id"] = $value1->user_id;
                $post["post_comment"][0]["user_name"] = $value1->user->name;
                $post["post_comment"][0]["username"] = $value1->user->username;
                $post["post_comment"][0]["comment"] = $value1->comment_data;
                $carbon1 = Carbon::parse(($value1->created_at))->diffForHumans();
                $post["post_comment"][0]["comment_time"] = $this->date_small($carbon1);
                $post["post_comment"][0]["user_picture"] = Cloudder::show($value1->user->profile_picture_small, array());

            }

            $post["like_all"] = [];

            $likesAll = $value->like()->where('like_type', '1')->latest()->offset(0)->limit(3)->get();
            $i = 0;
            foreach ($likesAll as $key1 => $value1) {
                $post["like_all"][$i]["post_id"] = $value->id;
                $post["like_all"][$i]["user_id"] = $value1->user_id;
                $post["like_all"][$i]["user_name"] = $value1->user->name;
                $post["like_all"][$i]["username"] = $value1->user->username;
                $post["like_all"][$i]["user_picture"] = Cloudder::show($value1->user->profile_picture_small, array());
                $i++;
            }

            array_push($postData, $post);

        }

        return $postData;
    }

    public function trending(Request $request)
    {
        if ($request->ajax()) {

            $TrendingPosts = Like::groupBy('post_id')
                ->select('post_id', DB::raw('count(post_id) as total'))
                ->where('created_at', '>=', Carbon::now()->subDays(1))
                ->orderby(DB::raw('total'), 'DESC')
                ->get();


            $postID = array();

            foreach ($TrendingPosts as $TrendingPost) {
                array_push($postID, $TrendingPost->post_id);
            }

            $postIDString = implode(",", $postID);

            $postAll = Post::wherein('id', $postID)
                ->orderby(DB::raw("FIELD(id, $postIDString)"))
                ->paginate(5);

            return $this->getPosts($postAll);

        } else {
            return redirect('/home');
        }
    }

    public function date_small($Date)
    {
        $Date = str_replace("second", "s", $Date);
        $Date = str_replace("ss", "s", $Date);
        $Date = str_replace("minute", "m", $Date);
        $Date = str_replace("ms", "m", $Date);
        $Date = str_replace("hour", "h", $Date);
        $Date = str_replace("hs", "h", $Date);
        $Date = str_replace("day", "d", $Date);
        $Date = str_replace("ds", "d", $Date);
        $Date = str_replace("week", "w", $Date);
        $Date = str_replace("ws", "w", $Date);
        $Date = str_replace("year", "y", $Date);
        $Date = str_replace("ys", "y", $Date);
        return $Date;
    }

    public function chatsList(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $user->id = $user->user_id;
            $conversations = Conversation:: where('user_id1', $user->id)
                ->orwhere('user_id2', $user->id)
                ->latest()
                ->get();

            $messagesList = array();
            foreach ($conversations as $conversation) {

                $auth = '';

                if ($conversation->user_id1 == $user->id) {
                    $auth = $conversation->status_1;
                } elseif ($conversation->user_id2 == $user->id) {
                    $auth = $conversation->status_2;
                }

                if ($auth == 2 || $auth == 1) {

                    $messages = array();
                    if ($conversation->user_id1 != $user->id) {
                        if ($conversation->type == 2) {
                            $messages["image"] = Cloudder::show('fabits/anonymous-small', array());
                            $messages["name"] = 'Anonymous - ' . $conversation->id;
                            $messages["username"] = '#';
                        } else {
                            $messages["name"] = $conversation->userFrom->name;
                            $messages["username"] = $conversation->userFrom->username;
                            $messages["image"] = Cloudder::show($conversation->userFrom->profile_picture_small, array());
                        }

                    } else {

                        if ($conversation->type == 2) {
                            $messages["name"] = $conversation->userTo->name . ' - Anonymous';
                        } else {
                            $messages["name"] = $conversation->userTo->name;
                        }
                        $messages["username"] = $conversation->userTo->username;
                        $messages["image"] = Cloudder::show($conversation->userTo->profile_picture_small, array());


                    }

                    $messageCount = Message::where('conversation_id', $conversation->id)
                        ->where('status', '<=', 1)
                        ->where('user_id', '!=', $user->id)
                        ->count();
                    $messages["count"] = $messageCount;

                    $message = null;

                    $message = Message::where('conversation_id', $conversation->id)->latest()->first();

                    $messages["auth"] = $auth;
                    $messages["conversation_id"] = $conversation->id;
                    if (count($message) == 0) {
                        $messages["time"] = Carbon::parse(($conversation->created_at))->toDateTimeString();
//                    $messages["time"] = ($conversation->created_at)->date;
                        $messages["time_tag"] = Carbon::parse(($conversation->created_at))->toFormattedDateString();


                    } else {

                        $messages["time"] = Carbon::parse(($message->created_at))->toDateTimeString();
//                    $messages["time"] = ($message->created_at)->date;
                        $messages["time_tag"] = Carbon::parse(($message->created_at))->toFormattedDateString();

                    }
                    if ($auth == 2) {
                        if (count($message) == 0) {
                            $messages["message"] = '';
                        } else {
                            $messages["message"] = $message->message;
                        }
                    } else
                        $messages["message"] = '';

                    if ($auth != -1)
                        array_push($messagesList, $messages);
                }

            }

            $messagesList1 = array();

            usort($messagesList, array($this, "cmp"));


            $i = 0;
            foreach ($messagesList as $ml) {

                $time = Carbon::now()->diffInDays(Carbon::parse($messagesList[$i]["time"]));
                if ($time >= 1) {

                    $messagesList[$i]["time"] = Carbon::parse(($messagesList[$i]["time"]))->format('j-m-y');


                } else {

                    $messagesList[$i]["time"] = Carbon::parse(($messagesList[$i]["time"]))->format('h:i a');
                }

                $i++;
            }

            return $messagesList;


//            return view('home.messages')
//                ->with('ajax', $ajax)
//                ->with('conversations', $messagesList);
        } else {

            return -1;
        }
    }

    function cmp($a, $b)
    {
        return strcmp($b['time'], $a['time']);
    }

    public function profile(Request $request, $token, $username)
    {

        $userProfile = Sentinel::findById($username);


        if (count($userProfile)) {
            $profileData = [];

            $user = oAuth::where([
                'token' => $token,
            ])->first();

            if ($user) {

                $user->id = $user->user_id;
                $followers = Follow::where('user_id2', $userProfile->id)
                    ->select('id')->count();
                $isFollow = Follow::where('user_id2', $userProfile->id)
                    ->where('user_id1', $user->id)
                    ->select('id')->count();
                $following = Follow::where('user_id1', $userProfile->id)
                    ->select('id')->count();
                $profileViews = Profileview::where('user_id2', $userProfile->id)
                    ->select('id')->count();

                $profileViews_user = Profileview::where('user_id2', $userProfile->id)
                    ->where('user_id1', $user->id)
                    ->latest()->first();

                $Privacy = Privacy::where('user_id', $userProfile->id)->first();

                if ($profileViews_user) {
                    $carbon1 = Carbon::parse(($profileViews_user->created_at))->diffInSeconds();

                    if ($carbon1 > 60) {
                        if ($user->id != $userProfile->id) {

                            Profileview::create([
                                'user_id1' => $user->id,
                                'user_id2' => $userProfile->id
                            ]);
                            $this->addNotification($userProfile->id, $user->id, 3, 0);

//                            $this->addNotification($userProfile, $user->id, 3, 0);
//                            event(new Notify($userProfile->id));

                        }
                    }

                } else {
                    if ($user->id != $userProfile->id) {
                        Profileview::create([
                            'user_id1' => $user->id,
                            'user_id2' => $userProfile->id
                        ]);
//                        $this->addNotification($userProfile, $user->id, 3, 0);
//                        event(new Notify($userProfile->id));


                    }
                }
                $postCount = Post::where('user_id', $userProfile->id)->select('id')
                    ->count();

                $isBlock = Block::where('user_id2', $userProfile->id)
                    ->where('user_id1', $user->id)
                    ->select('id')->count();

                $faceMatches = Facematch::where('user_id1', $userProfile->id)
                    ->orwhere('user_id2', $userProfile->id)
                    ->whereNotNull('user_ids')
                    ->select('id', 'user_ids')
//                ->where('user_ids')
                    ->get();

                $total = 0;
                $select = 0;
                foreach ($faceMatches as $faceMatch) {

                    if ($faceMatch->user_ids == $userProfile->id)
                        $select++;
                    $total++;
                }

                $yearCurr = Carbon::now()->year - "$userProfile->college_year";


                $collegeName = College_name::where('id', $userProfile->college_name_id)->select('name')->first()->name;

                $branchName = Branch::where('id', $userProfile->branch_id)->select('name')->first()->name;

                $profileData["college"] = $collegeName;
                $profileData["branch"] = $branchName;
                if ($yearCurr == 0)
                    $profileData["year"] = "";
                else
                    $profileData["year"] = "0" . $yearCurr;
                $profileData["followers"] = $followers;
                $profileData["following"] = $following;
                $profileData["profile_views"] = $profileViews;
                $profileData["posts"] = $postCount;
                $profileData["isFollow"] = $isFollow;
                $profileData["isBlock"] = $isBlock;

                if ($total == 0)
                    $profileData["faceMatch_Rating"] = "N/10";
                else
                    $profileData["faceMatch_Rating"] = round(($select / $total) * 10, 1) . "/10";

                if ($userProfile["birth_day"])
                    $dob = $userProfile["birth_day"] . " " . $this->monthname($userProfile["birth_month"]);
                else

                    $dob = '-';

                $userProfile["wall_picture_big"] = Cloudder::show($userProfile["wall_picture_big"], array());
                $userProfile["wall_picture_small"] = Cloudder::show($userProfile["wall_picture_small"], array());
                $userProfile["profile_picture_big"] = Cloudder::show($userProfile["profile_picture_big"], array());
                $userProfile["profile_picture_small"] = Cloudder::show($userProfile["profile_picture_small"], array());
                $profileData["wall_picture_big"] = $userProfile["wall_picture_big"];
                $profileData["wall_picture_small"] = $userProfile["wall_picture_small"];
                $profileData["profile_picture_big"] = $userProfile["profile_picture_big"];
                $profileData["profile_picture_small"] = $userProfile["profile_picture_small"];

                $profileData["id"] = $userProfile["id"];
                $profileData["location"] = $userProfile["hometown"];
                $profileData["username"] = $userProfile["username"];
                $profileData["name"] = $userProfile["name"];
                $profileData["intro"] = $userProfile["intro"];
                $profileData["relationship"] = Relationship::where([
                    'id' => $userProfile["relationship_id"]
                ])->first()->name;
                $profileData["dob"] = $dob;
                if ($Privacy != null) {


                    if ($Privacy->phone == 0)
                        $profileData["phone"] = -1;
                    else
                        $profileData["phone"] = $userProfile["phone"];
                } else {

                    $profileData["phone"] = "-1";
                }
                if ($user->id == $userProfile->id) {
                    $profileData["phone"] = $userProfile["phone"];
                }


                $json = json_encode($profileData);

                return $json;

            } else {

                return '-1';
            }
        } else {


            return '-1';
        }
    }

    public function monthname($month)
    {

        switch ($month) {

            case 1:
                return "Jan";
            case 2:
                return "Feb";
            case 3:
                return "Mar";
            case 4:
                return "Apr";
            case 5:
                return "May";
            case 6:
                return "June";
            case 7:
                return "July";
            case 8:
                return "Aug";
            case 9:
                return "Sep";
            case 10:
                return "Oct";
            case 11:
                return "Nov";
            case 12:
                return "Dec";


        }


    }

    public function like(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $user->id = $user->user_id;
            $user_id = $user->id;
            $this->validate($request, [
                'post_id' => 'bail|required|integer|exists:posts,id',
                'like_type' => 'bail|required|integer|between:0,1',
            ], [
                    'post_id.*' => 'Invalid Like!!',
                    'like_type.*' => 'Invalid Like!!',
                ]
            );

            $post_id = $request->post_id;
            $like_type = $request->like_type;
            $Q_like = Like::where('post_id', $post_id)
                ->where('user_id', $user_id);

            $like = $Q_like->get()->toArray();

            if (count($like) == 0) {

                Like::create([
                    'like_type' => $like_type,
                    'post_id' => $post_id,
                    'user_id' => $user_id,
                ]);

                if ($like_type == 1) {

                    UnfollowPost::where([
                        'post_id' => $post_id,
                        'user_id' => $user_id,
                    ])->delete();
                    $this->addNotification($user_id, $post_id, 0, 1);

                }

            } else {
                if ($like[0]["like_type"] == $like_type) {
                    $Q_like->delete();
                    if ($like_type == 1)
                        $this->removeNotification($user_id, $post_id, 0, 1);
                } else {

                    $Q_like->update(['like_type' => $like_type]);

                    if ($like_type == 1) {
                        UnfollowPost::where([
                            'post_id' => $post_id,
                            'user_id' => $user_id,
                        ])->delete();

                        $this->addNotification($user_id, $post_id, 0, 1);
                    }

                    if ($like_type == 0)
                        $this->removeNotification($user_id, $post_id, 0, 1);

                }
            }

            return $like_type;
        }
    }

    public function online(Request $resquest, $token)
    {

        $formatted_date = Carbon::now()->subSeconds(30)->toDateTimeString();
//        $result = DB::table('users')->where('last_seen','>=',$formatted_date)->select(['id','last_seen'])->get();

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $user = Sentinel::findById($user->user_id);

            $result = DB::table('users')
                ->where('id', '!=', $user->id)
                ->where('last_seen', '>=', $formatted_date)
                ->select(['id', 'name', 'profile_picture_small', 'last_seen', 'intro'])
                ->orderBy('last_seen', 'DESC')
                ->get();

            $result1 = DB::table('users')
                ->where('id', '!=', $user->id)
                ->where('last_seen', '<', $formatted_date)
                ->where('college_name_id', $user->college_name_id)
                ->where('branch_id', $user->branch_id)
                ->where('college_year', $user->college_year)
                ->select(['id', 'name', 'profile_picture_small', 'last_seen', 'intro'])
                ->orderBy('last_seen', 'DESC')
                ->get();

            $onlinedata = $this->getUsers($result);
            $onlinedata1 = $this->getUsers($result1);
            DB::table('users')
                ->where('id', $user->id)
                ->update(['last_seen' => Carbon::now(),]);
            $onlinedata = array_merge($onlinedata, $onlinedata1);

            $data = $onlinedata;

            return $data;
        }
    }

    public function getUsers($result)
    {

        $onlinedata = array();

        foreach ($result as $key => $value) {

            $online = array();
            $online["user_name"] = $value->name;
            if ($value->intro)
                $online["intro"] = $this->textLimit($value->intro, 30);
            else
                $online["intro"] = '';
            $online["id"] = $value->id;

            $carbon1 = Carbon::parse($value->last_seen)->diffForHumans(null, true);

            if (Carbon::now()->diffInSeconds(Carbon::parse($value->last_seen)) < 31) {

                $online["last_seen"] = "online";

            } else {

                $online["last_seen"] = $this->datesmall($carbon1);
            }


            $online["user_picture"] = Cloudder::show($value->profile_picture_small, array());
            array_push($onlinedata, $online);
        }

        return $onlinedata;
    }

    public function textLimit($text, $len)
    {

        if (strlen($text) > $len) {
            return substr($text, 0, $len) . "...";
        } else
            return $text;

    }

    public function datesmall($Date)
    {
        $Date = str_replace("second", "s", $Date);
        $Date = str_replace("ss", "s", $Date);
        $Date = str_replace("minute", "m", $Date);
        $Date = str_replace("ms", "m", $Date);
        $Date = str_replace("hour", "h", $Date);
        $Date = str_replace("hs", "h", $Date);
        $Date = str_replace("day", "d", $Date);
        $Date = str_replace("ds", "d", $Date);
        $Date = str_replace("week", "w", $Date);
        $Date = str_replace("ws", "w", $Date);
        $Date = str_replace("year", "y", $Date);
        $Date = str_replace("ys", "y", $Date);
        return $Date;
    }

    public function likes(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $postId = $request->source_id;

            $like_data = Like::where('post_id', $postId)->where('like_type', '1')->latest()->paginate(10);

            $likeData = array();

            foreach ($like_data as $key1 => $value1) {
                $like = array();
                $like["user_id"] = $value1->user_id;
                $like["user_name"] = $value1->user->name;
                $like["username"] = $value1->user->username;
                $like["user_picture"] = Cloudder::show($value1->user->profile_picture_small, array());
                $carbon1 = Carbon::parse(($value1->created_at))->diffForHumans();
                $like["time"] = $this->date_small($carbon1);
                array_push($likeData, $like);
            }

            return $likeData;
        }
    }

    public function comments(Request $request, $token, $postId)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $commentData = array();
            $comment = Comment::where('post_id', $postId)->latest()->paginate(10);

            foreach ($comment as $key => $value) {
                $post = array();
                $post["comment_id"] = $value->id;
                $post["post_id"] = $postId;
                $post["user_id"] = $value->user_id;
                $post["user_name"] = $value->user->name;
                $post["username"] = $value->user->username;
                $post["comment"] = $value->comment_data;
                $carbon1 = Carbon::parse(($value->created_at))->diffForHumans();
                $post["comment_time"] = $this->datesmall($carbon1);
                $post["user_picture"] = Cloudder::show($value->user->profile_picture_small, array());
                array_push($commentData, $post);

            }
            $commentData = array_reverse($commentData);
            return $commentData;

        }
    }

    public function comment(Request $request, $token)
    {
//        $this->validate($request, [
//            'post_id' => 'bail|required|integer|exists:posts,id',
//            'comment' => 'required',
//        ]);

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $Use_comment = $request->comment;
            $postId = $request->post_id;


            $comment = Comment::create([
                'comment_data' => $Use_comment,
                'post_id' => $postId,
                'user_id' => $userID,
            ]);

            UnfollowPost::where([
                'post_id' => $postId,
                'user_id' => $userID,
            ])->delete();
            $this->addNotification($userID, $postId, 0, 2);

            $commentData = [];
            $commentData["id"] = $comment->id;
            $carbon1 = Carbon::parse(($comment->created_at))->diffForHumans();
            $commentData["comment_time"] = $this->datesmall($carbon1);
            return $commentData;
        }
    }

    public function following(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $followers = Follow::where('user_id1', $userID)->latest()->get();

            $followData = array();

            foreach ($followers as $follower) {

                $userProfile = Sentinel::findUserByid($follower->user_id2);
                $follow = array();
                $follow["user_id"] = $userProfile->id;
                $follow["user_name"] = $userProfile->name;
                $follow["username"] = $userProfile->username;
                $follow["user_picture"] = Cloudder::show($userProfile->profile_picture_small, array());
                $carbon1 = Carbon::parse(($follower->created_at))->diffForHumans();
                $follow["time"] = $this->date_small($carbon1);
                array_push($followData, $follow);

            }
            return $followData;

        }
    }

    public function MessagesList(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $result = DB::select("SELECT *, messagesV2.created_at as 'conversation_time',
                    (select count(messagesV2.id) from messagesV2
                     left OUTER  JOIN group_lists
                     on group_lists.conversationsV2_id = messagesV2.conversationsV2_id
                     where  group_lists.user_id = ?
                     and group_lists.conversationsV2_id = gl.conversationsV2_id
                     and messagesV2.id > group_lists.lastread)
                      as countM, 
                    users.id as uid FROM group_lists as gl
                    left OUTER  JOIN  conversationsV2 as conv
                    on gl.conversationsV2_id = conv.id
                    left OUTER  JOIN  messagesV2
                    on gl.conversationsV2_id = messagesV2.conversationsV2_id
                    left OUTER JOIN users ON 
                    gl.user_id = users.id
                    where gl.conversationsV2_id
                    in (select conversationsV2_id from  group_lists where user_id =?)
                    and messagesV2.id = ( select max(id) from messagesV2 where conversationsV2_id = conv.id)
                    and gl.user_id != ?
                    and messagesV2.id > gl.lastDeleted
                    and gl.auth >0
                    GROUP BY messagesV2.conversationsV2_id
                    
                    ",
                [$userID, $userID, $userID,]);

            $chatList = array();

            foreach ($result as $res) {
                $chat = array();

                if ($res->type == 1 || $res->type == 2) {

                    $chat["name"] = $res->name;
                    $chat["image"] = Cloudder::show($res->profile_picture_small, array());

                    $chat["id"] = $res->id;
                    $chat["userID"] = $res->uid;
                    $chat["count"] = $res->countM;
                    $chat["auth"] = $res->auth;
                    $chat["type"] = $res->type;
                    $chat["conversation_id"] = $res->conversationsV2_id;
                    $chat["time"] = Carbon::parse(($res->conversation_time))->format('h:i a');
                    $chat["time_tag"] = Carbon::parse(($res->conversation_time))->toFormattedDateString();
                    $chat["message"] = $res->message;
                }
                array_push($chatList, $chat);

            }


            return $chatList;
        }
    }

    public function Messages()
    {
    }


    public function SocketMessage($Message, $userProfile, $list)
    {
        $messageSocket = array();
        $messageSocket["id"] = $Message->id;
        $messageSocket["message"] = $Message->message;


        $messageSocket["image"] = Cloudder::show($userProfile->profile_picture_small, array());

        $messageSocket["userIDS"] = $userProfile->id;
        $messageSocket["time"] = Carbon::parse(($Message->created_at))->format('h:i a');
        $messageSocket["time_tag"] = Carbon::parse(($Message->created_at))->toFormattedDateString();
        $messageSocket["conversation_id"] = $Message->conversationsV2_id;
        foreach ($list as $item) {
            if ($userProfile->id == $item->user_id) continue;
            event(new \App\Events\MessageV2($item->user_id, $messageSocket));
        }

    }

    public function SocketSeen($userId, $userProfile, $list)
    {

        $messageSocket = array();
        $otherId = null;
        $online = $userProfile->last_seen;
        $carbon1 = Carbon::parse($online)->diffForHumans(null, true);
        if (Carbon::now()->diffInSeconds(Carbon::parse($online)) < 31) {
            $online = "online";
        } else {
            $online = $this->datesmall($carbon1);
        }

        $messageSocket["lastSeen"] = $online;
        $messageSocket["userID"] = $userProfile->id;

        $messageSocket["image"] = Cloudder::show($userProfile->profile_picture_small, array());


        foreach ($list as $item) {
            if ($userId == $item->user_id) {
                $messageSocket["lastDelivered"] = $item->lastseen;
                $messageSocket["lastRead"] = $item->lastread;
                $messageSocket["conversation_id"] = $item->conversationsV2_id;
            } else
                $otherId = $item->user_id;

        }


        event(new SeenReadConversation($otherId, $messageSocket));

    }

    public function SocketChatOpen(Request $request, $token)
    {

    }

    public function UpdateMessageStatus($userID, $ConversationID, $lastDelivered, $lastRead)
    {

        GroupList::where([
            'user_id' => $userID,
            'conversationsV2_id' => $ConversationID,
        ])
            ->update([
                'lastread' => $lastRead,
                'lastseen' => $lastDelivered
            ]);
    }

    public function chatAllow(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $ConversationID = $request->conversation_Id;

            GroupList::where('user_id', '!=', $userID)
                ->where('conversationsV2_id', $ConversationID)
                ->update([
                    'auth' => '2',
                ]);
        }
    }


    public function chatBlock(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $ConversationID = $request->conversation_Id;

            GroupList::where('user_id', '!=', $userID)
                ->where('conversationsV2_id', $ConversationID)
                ->update([
                    'auth' => '0',
                ]);


        }


    }


    public function UpdateMessageStatus_Delivered($userID, $ConversationID, $lastDelivered)
    {

        GroupList::where([
            'conversationsV2_id' => $ConversationID,
            'user_id' => $userID
        ])->update(['lastseen' => $lastDelivered]);
    }


    public function SMessage(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $message = $request->message;
            $ConversationID = $request->conversation_Id;

            $Message = MessageV2::create([
                'conversationsV2_id' => $ConversationID,
                'message' => $message,
                'user_id' => $userID
            ]);

            $id = $Message->id;
//            $authList = Conversationv2::where('conversationsV2_id', $ConversationID)->first();
            $this->UpdateMessageStatus($userID, $ConversationID, $id, $id);

            $userProfile = Sentinel::findById($userID);
            $list = GroupList::where('conversationsV2_id', $ConversationID)->get();

            $this->SocketMessage($Message, $userProfile, $list);

            $this->SocketSeen($userID, $userProfile, $list);

            $data = array();
            $data["id"] = $id;
            $data["message"] = $message;
            $data["time"] = Carbon::parse(($Message->created_at))->format('h:i a');
            $data["time_tag"] = Carbon::parse(($Message->created_at))->toFormattedDateString();
            return $data;

        }
    }


    public function CMessage(Request $request, $token)
    {


        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $message = $request->message;
            $toUser = $request->conversation_Id;


            $isConversationExist = GroupList::where('user_id', $userID)
                ->join('conversationsV2', 'group_lists.conversationsV2_id', '=', 'conversationsV2.id')
                ->where('type', 1)
                ->whereIn('conversationsV2_id', function ($query) use ($toUser) {

                    $query->select('conversationsV2_id')->from('group_lists')->where('user_id', $toUser)
                        ->join('conversationsV2', 'group_lists.conversationsV2_id', '=', 'conversationsV2.id')
                        ->where('type', 1)
                        ->get();
                })
                ->first();


            $data = array();

            if (count($isConversationExist) > 0) {


                $Message = MessageV2::create([
                    'conversationsV2_id' => $isConversationExist->id,
                    'message' => $message,
                    'user_id' => $userID
                ]);

                $userProfile = Sentinel::findById($toUser);
                $id = $Message->id;
                $ConversationID = $Message->conversationsV2_id;
                $data["id"] = $id;
                $data["name"] = $userProfile->name;
                $data["userID"] = $toUser;
                $data["userIDS"] = $userID;
                $data["image"] = Cloudder::show($userProfile->profile_picture_small, array());
                $data["count"] = "0";
                $data["auth"] = "2";
                $data["conversation_id"] = $ConversationID;
                $data["time"] = Carbon::parse(($Message->created_at))->format('h:i a');
                $data["time_tag"] = Carbon::parse(($Message->created_at))->toFormattedDateString();
                $data["message"] = $Message->message;


                $this->UpdateMessageStatus($userID, $ConversationID, $id, $id);
                $userProfile = Sentinel::findById($userID);
                $list = GroupList::where('conversationsV2_id', $ConversationID)->get();

                $this->SocketMessage($Message, $userProfile, $list);

                $this->SocketSeen($userID, $userProfile, $list);

            } else {

                $id = Conversationv2::insertGetId([
                    'type' => 1,
                    'name' => "",
                    'image' => ""
                ]);


                GroupList::insert([
                    'user_id' => $userID,
                    'conversationsV2_id' => $id,
                    'status' => 0,
                    'auth' => '1',
                    'lastseen' => 0,
                ]);

                GroupList::insert([
                    'user_id' => $toUser,
                    'conversationsV2_id' => $id,
                    'status' => 0,
                    'auth' => '2',
                    'lastseen' => 0,
                ]);

                $Message = MessageV2::create([
                    'conversationsV2_id' => $id,
                    'message' => $message,
                    'user_id' => $userID
                ]);

                $userProfile = Sentinel::findById($toUser);
                $id = $Message->id;
                $ConversationID = $Message->conversationsV2_id;
                $data["id"] = $id;
                $data["name"] = $userProfile->name;
                $data["userID"] = $toUser;
                $data["userIDS"] = $userID;
                $data["image"] = Cloudder::show($userProfile->profile_picture_small, array());
                $data["count"] = "0";
                $data["auth"] = "2";
                $data["conversation_id"] = $ConversationID;
                $data["time"] = Carbon::parse(($Message->created_at))->format('h:i a');
                $data["time_tag"] = Carbon::parse(($Message->created_at))->toFormattedDateString();
                $data["message"] = $Message->message;

                $this->UpdateMessageStatus($userID, $ConversationID, $id, $id);
                $userProfile = Sentinel::findById($userID);
                $list = GroupList::where('conversationsV2_id', $ConversationID)->get();

                $this->SocketMessage($Message, $userProfile, $list);

                $this->SocketSeen($userID, $userProfile, $list);
            }

            return array($data);

        }
    }

    public function newMessage(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $result = GroupList::
            where('group_lists.user_id', $userID)
                ->whereColumn('messagesV2.id', '>', 'group_lists.lastseen')
                ->join('conversationsV2', 'group_lists.conversationsV2_id', '=', 'conversationsV2.id')
                ->join('messagesV2', 'group_lists.conversationsV2_id', '=', 'messagesV2.conversationsV2_id')
                ->join('users', 'messagesV2.user_id', '=', 'users.id')
                ->select('*', 'users.id as uid')
                ->orderBy('messagesV2.conversationsV2_id')
                ->orderBy('messagesV2.id')
                ->get();

            $userProfile = Sentinel::findById($userID);

            $chatList = array();
            $isIDSame = -1;

            foreach ($result as $res) {
                $chat = array();
                $chat["id"] = $res->id;


                $checkAuth = GroupList::where('user_id', '!=', $userID)
                    ->where('conversationsV2_id', $res->conversationsV2_id)->first();

                if ($checkAuth->auth == 0)
                    continue;

                if ($isIDSame != $res->conversationsV2_id) {
                    $this->UpdateMessageStatus_Delivered($userID, $res->conversationsV2_id, $res->id);
                    $isIDSame = $res->conversationsV2_id;

                }


                if ($res->type == 1 || $res->type == 2) {

                    $chat["id"] = $res->id;
                    $chat["name"] = $res->uid;
                    $chat["userIDS"] = (string)$res->user->id;
                    $chat["image"] = Cloudder::show($res->profile_picture_small, array());
                    $chat["conversation_id"] = $res->conversationsV2_id;
                    $chat["count"] = $res->count;
                    $chat["auth"] = $res->count;
                    $chat["type"] = $res->type;
                    $chat["time"] = Carbon::parse(($res->created_at))->format('h:i a');
                    $chat["time_tag"] = Carbon::parse(($res->created_at))->toFormattedDateString();
                    $chat["message"] = $res->message;

                }

                $list = GroupList::where('conversationsV2_id', $res->conversationsV2_id)->get();
//                $userProfile = Sentinel::findById($userID);


                $this->SocketSeen($userID, $userProfile, $list);


                array_push($chatList, $chat);
            }


            return $chatList;

        }
    }


    public function readConversation(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $conversationId = $request->conversationId;
            $lastRead = $request->lastRead;
            $lastReceived = $request->lastReceived;


            if (strlen($lastReceived) > 0) {

                $this->UpdateMessageStatus_Delivered($userID, $conversationId, $lastReceived);
                $list = GroupList::where('conversationsV2_id', $conversationId)->get();
                $userProfile = Sentinel::findById($userID);


                $this->SocketSeen($userID, $userProfile, $list);

            } else {

                $this->UpdateMessageStatus($userID, $conversationId, $lastRead, $lastRead);
                $list = GroupList::where('conversationsV2_id', $conversationId)->get();
                $userProfile = Sentinel::findById($userID);


                $this->SocketSeen($userID, $userProfile, $list);


            }

        }

    }

    public function forceReadConversation(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $conversationId = $request->conversationId;
            $Message = MessageV2:: where('conversationsV2_id', $conversationId)->latest()->first();
            $this->UpdateMessageStatus($userID, $conversationId, $Message->id, $Message->id);
            $list = GroupList::where('conversationsV2_id', $conversationId)->get();
            $userProfile = Sentinel::findById($userID);


            $this->SocketSeen($userID, $userProfile, $list);
        }

    }

    public function typing(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $conversationId = $request->conversationId;
            $messageSocket = array();

            $list = GroupList::where('conversationsV2_id', $conversationId)->where('user_id', '!=', $userID)->get();

            $userProfile = Sentinel::findById($userID);

            $messageSocket["typing"] = "Typing...";
            $messageSocket["userID"] = $userID;
            $messageSocket["image"] = Cloudder::show($userProfile->profile_picture_small, array());

            foreach ($list as $item) {
                event(new TypingV2($item->user_id, $messageSocket, $conversationId));
            }

        }

    }


    public function online_conversation(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $conversationId = $request->conversationId;
            $type = $request->type;

            $list = GroupList::where('conversationsV2_id', $conversationId)->where('user_id', '!=', $userID)->get();

            $messageSocket = array();
            $messageSocket["type"] = $type;
            $messageSocket["conversation_id"] = $conversationId;

            foreach ($list as $item) {
                event(new OnlineConversation($item->user_id, $messageSocket));
            }

        }

    }


    public function conversationInit(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $conversationId = $request->conversationId;
            $lastRead = null;
            $lastDelivered = null;
            $lastSeen = null;

            $group = GroupList::where('conversationsV2_id', $conversationId)
                ->where('user_id', '!=', $userID)
                ->first();

            $lastDelivered = $group->lastseen;
            $lastRead = $group->lastread;

            if (count($group) > 0)
                $otherUserID = $group->user_id;
            else
                $otherUserID = $conversationId;

            $last = DB::table('users')
                ->where('id', $otherUserID)
                ->select('last_seen', 'profile_picture_small')
                ->first();

            $online = $last->last_seen;
            $carbon1 = Carbon::parse($online)->diffForHumans(null, true);
            if (Carbon::now()->diffInSeconds(Carbon::parse($online)) < 31) {
                $online = "online";
            } else {
                $online = $this->datesmall($carbon1);
            }

            return array(array(
                'lastDelivered' => $lastDelivered,
                'conversation_id' => $conversationId,
                'lastRead' => $lastRead,
                'lastSeen' => $online,
                'userID' => $group->user_id,
                'image' => Cloudder::show($last->profile_picture_small, array())
            ));
        }

    }


    public function conversationDelete(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $conversationId = $request->conversation_Id;

            $res = MessageV2:: where('conversationsV2_id', $conversationId)
                ->orderBy('id', 'DESC')->first();


            GroupList::where('user_id', '!=', $userID)
                ->where('conversationsV2_id', $conversationId)
                ->update([
                    'lastDeleted' => $res->id,
                ]);
        }

    }


    public function postText(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $type_id = 1;
            $post_id = null;
            $postData = $request->text;

            $post1 = Post::create([
                'text' => $postData,
                'type_id' => $type_id,
                'user_id' => $userID
            ]);

            $post_id = $post1->id;

//            preg_match_all("/(#\\w+)/", $postData, $output_array);
//            foreach ($output_array[0] as $key => $value) {
//                Hashtag::create([
//                    'tag' => $value,
//                    'post_id' => $post_id,
//                ]);
//            }

            $post["id"] = $post_id;
            $post["user_id"] = $user->id;
            $post["text"] = $postData;
            return $post;

        }
    }


    public function postImage(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $type_id = 2;
            $post_id = null;
            $postData = $request->metadata;

            $post1 = Post::create([
                'text' => $postData,
                'type_id' => $type_id,
                'user_id' => $userID
            ]);

            $post_id = $post1->id;

            try {

                Cloudder::upload($request->file('uploadfile'), null,
                    array(
                        "format" => "jpg",
                        "width" => 500, "height" => 500, "crop" => "limit",
                    ));

            } catch (Exception $e) {
                return $this->ajaxError('Invalid Image format !');
            }

            $image2 = Cloudder::getResult();
            $image = $image2["public_id"];
            $image1 = $image2["height"];
            $image01 = $image2["width"];
            $image1 = $image1 / $image01;
            $value = $image . '-' . $image1;

            Post_data::create([
                'source' => $value,
                'type' => $type_id,
                'data' => null,
                'post_id' => $post_id,

            ]);

            $pieces = explode("-", $value);
            $post['source'] = Cloudder::show($pieces[0], array());
            $post['height'] = $pieces[1];
            $post["id"] = $post_id;
            $post["user_id"] = $user->id;
            $post["text"] = $postData;

            return $post;

        }
    }


    public function chatImageUpload(Request $request, $token)
    {

//        return "WTF";
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $postData = $request->metadata;
            $ConversationID = $request->conversation_Id;
//            return $ConversationID;
            try {

                Cloudder::upload($request->file('uploadfile'), null,
                    array(
                        "format" => "jpg",
                        "width" => 500, "height" => 500, "crop" => "limit",
                    ));

            } catch (Exception $e) {
                return $this->ajaxError('Invalid Image format !');
            }

            $image2 = Cloudder::getResult();
            $image = $image2["public_id"];
            $image = Cloudder::show($image, array());

            $message = "[IMAGE][[$image][$postData]]";
            $request->message = $message;

            if ($ConversationID == "-1") {
                return $this->CMessage($request, $token);
            } else
                return $this->SMessage($request, $token);
        }
    }


    public function notification(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $myID = Sentinel::findById($userID);
            $FinalList = array();
            $followers = Follow::where('user_id1', $userID)->select('user_id2')->get();

            $UserNotification = Notification::select(['id', 'source_id', 'type', 'activity_type', 'created_at'])
                ->where('user_id', $userID)
                ->groupby(['source_id', 'type'])
                ->orderby('created_at', 'desc')
                ->offset(0)
                ->limit(15)
                ->get();

            $unFollows = UnfollowPost::where('user_id', $userID)
                ->select('post_id')
                ->get();
            $i = 0;
            foreach ($UserNotification as $notification) {
                foreach ($unFollows as $unFollow) {
                    if ($notification->type == 0 && $unFollow->post_id == $notification->source_id) {
                        unset($UserNotification[$i]);
                    }
                }
                $i++;
            }

            foreach ($UserNotification as $notification) {
                $notify = array();
                $singleNotification = Notification::where('source_id', $notification->source_id)
                    ->where('type', $notification->type)
                    ->where('created_at', '>=', $notification->created_at)
                    ->latest()
                    ->get();

                $groupNotifications = collect($singleNotification)->groupBy('activity_type');

                foreach ($groupNotifications as $groupNotification) {

                    $count = 0;
                    $type = 0;
                    $activity_type = 0;
                    $name = null;
                    $userName = null;
                    $image = null;
                    $suffix = "";
                    $prefix = "";
                    $myImage = Cloudder::show($myID->profile_picture_small, array());
                    $myUsername = $myID->id;
                    $source_id = null;

                    foreach ($groupNotification as $LastNotification) {
                        $type = $LastNotification->type;
                        $activity_type = $LastNotification->activity_type;
                        if ($notification->type == 0 && $notification->activity_type == 0) {

                            $prefix = "of yours";

                        } else if ($LastNotification->type == 0) {
                            $isFound = false;
                            foreach ($followers as $follower) {
                                if ($follower->user_id2 == $LastNotification->user_id) {
                                    $isFound = true;
                                    break;
                                }
                            }
                            if (!$isFound)
                                continue;
                            $prefix = "you follow";

                        }


                        if ($LastNotification->type == 1 || $LastNotification->type == 2 || $LastNotification->type == 3) {
                            if ($LastNotification->user_id != $userID)
                                break;
                        }


                        $user_id = $LastNotification->user_id;
                        if ($count == 0) {
                            $source_id = $LastNotification->source_id;
                            if ($LastNotification->type == 2)
                                $user_id = $source_id;
                            $user = Sentinel::findById($user_id);
                            $name = $user->name;
                            $userName = $user->username;
                            $image = Cloudder::show($user->profile_picture_small, array());
                        }

                        $count++;
                    }


                    if ($count > 0) {

                        if ($type == 0 && ($activity_type == 1 || $activity_type == 2)) { //post

                            if ($count > 1)
                                $suffix = $name . " and " . ($count - 1) . " more people have";
                            else
                                $suffix = $name . " has";

                        } elseif ($type == 1) { // follow

                            $suffix = $name;

                        } elseif ($type == 2) { // like hate

                            if ($count > 1)
                                $suffix = ($count);
                            else
                                $suffix = "";
                            $prefix = $name;

                        } elseif ($type == 3) { // visit

                            if ($count > 1)
                                $suffix = ($count) . "  people have";
                            else
                                $suffix = "Someone has";
                            $prefix = "";
                            $source_id = $myUsername;
                            $image = $myImage;
                        } else {

                            continue;
                        }

                        $notify["message"] = $this->NotificationMessage($type, $activity_type, $suffix, $prefix);
                        $notify["name"] = $name;
                        $notify["image"] = $image;
                        $notify["source_id"] = $source_id;
                        $notify["type"] = $type;
                        $notify["activity_type"] = $activity_type;
                        array_push($FinalList, $notify);
                    }
                }


            }

            $last_noti = Notification::latest()->first()->id;

            DB::table('users')
                ->where('id', $userID)
                ->update([
                    'last_notification' => $last_noti
                ]);

            return $FinalList;

        }
    }

    public function newNotification(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $myID = Sentinel::findById($userID);
            $FinalList = array();
            $followers = Follow::where('user_id1', $userID)->select('user_id2')->get();

            $UserNotification = Notification::select(['id', 'source_id', 'type', 'activity_type', 'created_at'])
                ->where('user_id', $userID)
                ->groupby(['source_id', 'type'])
                ->orderby('created_at', 'desc')
                ->offset(0)
                ->limit(15)
                ->get();

            $unFollows = UnfollowPost::where('user_id', $userID)
                ->select('post_id')
                ->get();
            $i = 0;
            foreach ($UserNotification as $notification) {
                foreach ($unFollows as $unFollow) {
                    if ($notification->type == 0 && $unFollow->post_id == $notification->source_id) {
                        unset($UserNotification[$i]);
                    }
                }
                $i++;
            }

            foreach ($UserNotification as $notification) {
                $notify = array();
                $singleNotification = Notification::where('source_id', $notification->source_id)
                    ->where('type', $notification->type)
                    ->where('id', '>', $myID->last_notification)
                    ->where('created_at', '>=', $notification->created_at)
                    ->latest()
                    ->get();

                $groupNotifications = collect($singleNotification)->groupBy('activity_type');

                foreach ($groupNotifications as $groupNotification) {

                    $count = 0;
                    $type = 0;
                    $activity_type = 0;
                    $name = null;
                    $userName = null;
                    $image = null;
                    $suffix = "";
                    $prefix = "";
                    $myImage = Cloudder::show($myID->profile_picture_small, array());
                    $myUsername = $myID->id;
                    $source_id = null;

                    foreach ($groupNotification as $LastNotification) {
                        $type = $LastNotification->type;
                        $activity_type = $LastNotification->activity_type;
                        if ($notification->type == 0 && $notification->activity_type == 0) {

                            $prefix = "of yours";

                        } else if ($LastNotification->type == 0) {
                            $isFound = false;
                            foreach ($followers as $follower) {
                                if ($follower->user_id2 == $LastNotification->user_id) {
                                    $isFound = true;
                                    break;
                                }
                            }
                            if (!$isFound)
                                continue;
                            $prefix = "you follow";

                        }


                        if ($LastNotification->type == 1 || $LastNotification->type == 2 || $LastNotification->type == 3) {
                            if ($LastNotification->user_id != $userID)
                                break;
                        }


                        $user_id = $LastNotification->user_id;
                        if ($count == 0) {
                            $source_id = $LastNotification->source_id;
                            if ($LastNotification->type == 2)
                                $user_id = $source_id;
                            $user = Sentinel::findById($user_id);
                            $name = $user->name;
                            $userName = $user->username;
                            $image = Cloudder::show($user->profile_picture_small, array());
                        }

                        $count++;
                    }


                    if ($count > 0) {

                        if ($type == 0 && ($activity_type == 1 || $activity_type == 2)) { //post

                            if ($count > 1)
                                $suffix = $name . " and " . ($count - 1) . " more people have";
                            else
                                $suffix = $name . " has";

                        } elseif ($type == 1) { // follow

                            $suffix = $name;

                        } elseif ($type == 2) { // like hate

                            if ($count > 1)
                                $suffix = ($count);
                            else
                                $suffix = "";
                            $prefix = $name;

                        } elseif ($type == 3) { // visit

                            if ($count > 1)
                                $suffix = ($count) . "  people have";
                            else
                                $suffix = "Someone has";
                            $prefix = "";
                            $source_id = $myUsername;
                            $image = $myImage;
                        } else {

                            continue;
                        }

                        $notify["message"] = $this->NotificationMessage($type, $activity_type, $suffix, $prefix);
                        $notify["name"] = $name;
                        $notify["image"] = $image;
                        $notify["source_id"] = $source_id;
                        $notify["type"] = $type;
                        $notify["activity_type"] = $activity_type;
                        array_push($FinalList, $notify);
                    }
                }


            }

            $last_noti = Notification::latest()->first()->id;

            DB::table('users')
                ->where('id', $userID)
                ->update([
                    'last_notification' => $last_noti
                ]);

            return $FinalList;

        }
    }


    public function settings(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $setting_name = $request->setting_name;

            switch ($setting_name) {

                case 'S_STATUS':
                    $validator = Validator::make($request->all(), [
                        'S_STATUS' => 'bail|required'
                    ]);

                    if ($validator->fails())
                        return $validator->messages()->get("S_STATUS")[0];

                    $value = $request->S_STATUS;
                    return $this->setSetting($userID, 'intro', $value);
                    break;

                case 'S_USERNAME':
                    $validator = Validator::make($request->all(), [
                        'S_USERNAME' => 'bail|required|alpha_dash|max:20|unique:users,username',
                    ]);

                    if ($validator->fails())
                        return $validator->messages()->get("S_USERNAME")[0];

                    $value = $request->S_USERNAME;
                    return $this->setSetting($userID, 'username', $value);
                    break;

                case 'S_EMAIL':
                    $validator = Validator::make($request->all(), [
                        'S_EMAIL' => 'bail|email',
                    ]);

                    if ($validator->fails())
                        return $validator->messages()->get("S_EMAIL")[0];

                    $value = $request->S_EMAIL;
                    $this->setOptionalSetting($userID, 'email', $value);
                    break;

                case 'S_FACEBOOK':
                    $validator = Validator::make($request->all(), [
                        'S_FACEBOOK' => 'bail|url',
                    ]);

                    if ($validator->fails())
                        return $validator->messages()->get("S_FACEBOOK")[0];

                    $value = $request->S_FACEBOOK;
                    $this->setOptionalSetting($userID, 'facebook', $value);
                    break;

                case 'S_WHATSAPP':

                    $validator = Validator::make($request->all(), [
                        'S_WHATSAPP' => 'bail|integer|digits:10',
                    ]);

                    if ($validator->fails())
                        return $validator->messages()->get("S_WHATSAPP")[0];

                    $value = $request->S_WHATSAPP;
                    $this->setOptionalSetting($userID, 'whatsapp', $value);
                    break;

                case 'S_OTP':
                    $validator = Validator::make($request->all(), [
                        'S_OTP' => 'bail|integer|digits:4',
                    ]);

                    if ($validator->fails())
                        return $validator->messages()->get("S_OTP")[0];


                    $value = $request->S_OTP;
                    $value1 = $request->status;
                    return $this->setPhone($userID, $value, $value1);
                    break;

                case 'S_LOCATION':
                    $validator = Validator::make($request->all(), [
                        'S_LOCATION' => 'bail|required',
                    ]);

                    if ($validator->fails())
                        return $validator->messages()->get("S_LOCATION")[0];

                    $value = $request->S_LOCATION;
                    return $this->setSetting($userID, 'hometown', $value);
                    break;

                case 'S_RELATIONSHIP':

                    $value = $request->S_RELATIONSHIP;
                    if ($value == 'Single')
                        $value = 1;
                    else if ($value == 'Committed')
                        $value = 2;
                    else if ($value == 'Complicated')
                        $value = 3;
                    else
                        return "Invalid";

                    return $this->setSetting($userID, 'relationship_id', $value);
                    break;

                case 'S_P_PHONE':
                    $value = $request->S_P_PHONE == "Private" ? 0 : 1;

                    return $this->setPrivacySetting($userID, 'phone', $value);
                    break;
                case 'S_P_FOLLOWERS':
                    $value = $request->S_P_FOLLOWERS == "Private" ? 0 : 1;
                    return $this->setPrivacySetting($userID, 'followers', $value);
                    break;
                case 'S_P_FOLLOWING':
                    $value = $request->S_P_FOLLOWING == "Private" ? 0 : 1;
                    return $this->setPrivacySetting($userID, 'following', $value);
                    break;
                case 'S_P_FACEMATCH':
                    $value = $request->S_P_FACEMATCH == "Private" ? 0 : 1;
                    return $this->setPrivacySetting($userID, 'facematch', $value);
                    break;
                case 'S_A_LOGIN':
                    $value = $request->S_A_LOGIN == "Private" ? 0 : 1;
                    return $this->setSmsSetting($userID, 'login', $value);
                    break;
                case 'S_A_MESSAGE':
                    $value = $request->S_A_MESSAGE == "Private" ? 0 : 1;
                    return $this->setSmsSetting($userID, 'messages', $value);
                    break;
                case 'S_A_NOTIFICATION':
                    $value = $request->S_A_NOTIFICATION == "Private" ? 0 : 1;
                    return $this->setSmsSetting($userID, 'notifications', $value);
                    break;
                case 'S_A_ANONY_MESSAGE':
                    $value = $request->S_A_ANONY_MESSAGE == "Private" ? 0 : 1;
                    return $this->setSmsSetting($userID, 'anonymous', $value);
                    break;


            }


        }

    }

    public function setSetting($UserID, $column, $value)
    {

        DB::table('users')
            ->where('id', $UserID)
            ->update([
                $column => $value,
            ]);

        return "1";

    }

    public function setOptionalSetting($UserID, $column, $value)
    {

        Optional::where([
            'type' => $column,
            'user_id' => $UserID,
        ])->update([
            'data' => $value
        ]);

    }

    public function setSmsSetting($UserID, $column, $value)
    {

        Sms::where([
            'user_id' => $UserID,
        ])->update([$column => $value]);

        return "1";
    }

    public function setPrivacySetting($UserID, $column, $value)
    {

        Privacy::where([
            'user_id' => $UserID,
        ])->update([$column => $value]);

        return "1";

    }


    public function randomProfiles(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $myID = Sentinel::findById($userID);

            $searches = DB::table('users')
                ->where('id', '!=', $userID)
                ->where('gender', '!=', $myID->gender)
                ->orderBy(DB::raw('RAND()'))
                ->paginate(5);

            $profiles = array();
            foreach ($searches as $item) {
                $result = array();
                $result["profile_picture_big"] = Cloudder::show($item->profile_picture_big, array());
                $result["name"] = $item->name;
                $result["id"] = $item->id;
                $result["username"] = $item->username;
                $result["intro"] = $item->intro;
                array_push($profiles, $result);
            }

            return $profiles;

        }
    }


    public function my_following(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $following = Follow::where('user_id1', $userID)
                ->select('user_id2')->get();

            return $following;
        }
    }


    public function NotificationMessage($typeid, $activity_type, $suffix, $prefix)
    {

        $type[0][0] = "updated his status";
        $type[0][1] = "liked a post";
        $type[0][2] = "commented on a post";
        $type[0][3] = "updated his profile picture";
        $type[0][4] = "updated his wall picture";
        $type[0][5] = "uploaded a photo";

        $type[1][0] = "now follows";

        $type[2][0] = " like " . $prefix . " more than YOU";
        $type[2][1] = " like YOU more than " . $prefix;
        if ($typeid == 2) {
            $prefix = '';
        }
        $type[3][0] = "visited your profile";

        if ($typeid == 2) {
            $suffix = "People";

        }

        $template = $type[$typeid][$activity_type];

        return $suffix . ' ' . $template . ' ' . $prefix . '.';


    }


    public function search(Request $request, $token, $search, $type)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;


            if ($type == "user") {

                $search = str_replace("+", " ", $search);

                $searchList = array();
                $searches = DB::table('users')
                    ->where('name', 'like', '%' . $search . '%')
                    ->where('id', '!=', $userID)
                    ->orwhere('username', 'like', '%' . $search . '%')
                    ->orwhere('college_id', 'like', '%' . $search . '%')
                    ->orwhere('university_id', 'like', '%' . $search . '%')
                    ->orwhere('phone', 'like', $search . '%')
                    ->paginate(10);

                foreach ($searches as $search) {

                    $search_user = array();
                    $search_user["name"] = $search->name;
                    $search_user["id"] = $search->id;
                    $search_user["username"] = $search->username;
                    $search_user["intro"] = $search->intro;
                    $search_user["image"] = Cloudder::show($search->profile_picture_small, array());
                    array_push($searchList, $search_user);
                }
                return $searchList;

            } else if ($type == "post") {

                $postAll = Post::where('id', $search)
                    ->get();
                return $this->getPosts($postAll, $user);

            } else if ($type == "pool") {

                $postAll = Post::join('users', 'posts.user_id', '=', 'users.id')
                    ->where('college_name_id', $search)
                    ->select('*', 'posts.id as id')
                    ->orderby('posts.id', 'DESC')
                    ->paginate(5);
                return $this->getPosts($postAll, $user);
            } else if ($type == "profile") {


                $postAll = Post::where('user_id', $search)->latest()->paginate(5);


                return $this->getPosts($postAll, $user);

            }

        }
    }


    public
    function pools(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $result = array();

            $psit = array();
            $psit["name"] = "PSIT";
            $psit["image"] = "http://res.cloudinary.com/fabits-in/image/upload/v1492351817/ec2ef755-ddc8-4c47-ab10-3f77351bc532_hl5mc3_ka8xjt.jpg";
            $psit["search_id"] = "164";

            $psitCOE = array();
            $psitCOE["name"] = "PSIT-COE";
            $psitCOE["image"] = "http://res.cloudinary.com/fabits-in/image/upload/v1492353532/psitcoe_z2ri3z.png";
            $psitCOE["search_id"] = "348";

            $psitCHE = array();
            $psitCHE["name"] = "PSIT-CHE";
            $psitCHE["image"] = "http://res.cloudinary.com/fabits-in/image/upload/v1492353532/psitche_yjsbzm.png";
            $psitCHE["search_id"] = "1000";

            $naraina = array();
            $naraina["name"] = "NARAINA";
            $naraina["image"] = "http://res.cloudinary.com/fabits-in/image/upload/v1492353839/naraina_mksf6y.png";
            $naraina["search_id"] = "287";

            array_push($result, $psit);
            array_push($result, $psitCOE);
            array_push($result, $psitCHE);
            array_push($result, $naraina);

            return $result;

        }
    }


    public
    function deletePost(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $post_id = $request->post_id;

            $isdone = Post::where('id', $post_id)
                ->where('user_id', $userID)
                ->delete();

            return $isdone;
        }
    }


    public
    function deleteComment(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $post_id = $request->post_id;
            $id = $request->id;

            $isDone = Comment::where('post_id', $post_id)
                ->where('id', $id)
                ->where('user_id', $userID)
                ->delete();

            return $isDone;
        }
    }


    public function follow(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $user1 = $user->user_id;
            $user2 = $request->user_id;

            $follow = Follow::where([
                ['user_id1', $user1],
                ['user_id2', $user2],
            ])->first();

            if ($user1 != $user2) {
                if ($follow) {

                    $follow->delete();
                    $this->removeNotification($user2, $user1, 1, 0);

                    return '0';

                } else {

                    Follow::create([
                        'user_id1' => $user1,
                        'user_id2' => $user2,
                    ]);
                    $this->addNotification($user2, $user1, 1, 0);

                    return '1';
                }
            }
        }
    }

    public function unFollowPost(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $post_id = $request->post_id;

            UnfollowPost::create([
                'post_id' => $post_id,
                'user_id' => $userID,
            ]);

        }
    }

    public function checkFaceMatch(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $user = Sentinel::findById($userID);


            $check = Facematch::where('user_id', $userID)->latest()->first();

            $carbon = 1;
            if (count($check))
                $carbon = Carbon::now()->diffInHours(Carbon::parse($check->created_at));

            if ($carbon >= 1) {

                $result = DB::table('users')
                    ->where('id', '!=', $user->id)
                    ->where('branch_id', '=', $user->branch_id)
                    ->where('college_year', '=', $user->college_year)
                    ->where('college_name_id', '=', $user->college_name_id)
                    ->select('id', 'name', 'username', 'profile_picture_big', 'college_year', 'college_name_id', 'branch_id')
                    ->get();
                $Fuser1 = '';
                $Fuser2 = '';
                do {
                    $i = 0;
                    $users = collect($result)->random(2)->all();
                    foreach ($users as $ruser) {
                        if ($i == 0)
                            $Fuser1 = $ruser;
                        else
                            $Fuser2 = $ruser;
                        $i++;
                    }
                    $resultcheck = Facematch::where([
                        ['user_id', $user->id],
                        ['user_id1', $Fuser1->id],
                        ['user_id2', $Fuser2->id],
                    ])->orwhere([
                        ['user_id', $user->id],
                        ['user_id1', $Fuser2->id],
                        ['user_id2', $Fuser1->id],
                    ])
                        ->get();
                } while (count($resultcheck));
                $fmatch = Facematch::create([
                    'user_id' => $user->id,
                    'user_id1' => $Fuser1->id,
                    'user_id2' => $Fuser2->id,
                    'user_ids' => null,
                ]);
                $img1 = collect($Fuser1)->get('profile_picture_big');
                $img2 = collect($Fuser2)->get('profile_picture_big');
                $Fuser1 = collect($Fuser1)->put('profile_picture_big', Cloudder::show($img1, array()));
                $Fuser2 = collect($Fuser2)->put('profile_picture_big', Cloudder::show($img2, array()));

                $Fuser1 = collect($Fuser1)->put('fid', $fmatch->id);
                $Fuser2 = collect($Fuser2)->put('fid', $fmatch->id);

                $returnUser = array();
                $returnUser["user_1"] = $Fuser1;
                $returnUser["user_2"] = $Fuser2;


                return $returnUser;
            } else
                return [];
        }
    }

    public function changePassword(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $prev = $request->prev;
            $new = $request->new;
            $confirm = $request->confirm;

            $user = Sentinel::findById($userID);

            Sentinel::authenticate(array(
                'username' => $user->username,
                'password' => $prev,
            ), false);

            if ($user = Sentinel::check()) {

                Sentinel::update($user, array('password' => $new));

            }

        }
    }


    public function changePhoneno(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $post_id = $request->post_id;

            UnfollowPost::create([
                'post_id' => $post_id,
                'user_id' => $userID,
            ]);

        }
    }


    public function contactUS(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $msg = $request->message;

            Reports::create([
                'source' => $userID,
                'type' => 'fabits',
                'comment' => $msg
            ]);

        }
    }

    public function logout(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            oAuth::where([
                'user_id' => $userID,
            ])->delete();
        }
    }


    public function Block(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $user_id = $request->user_id;


            $block = Block::where([
                ['user_id1', $userID],
                ['user_id2', $user_id],
            ])->first();

            if ($userID != $user_id) {
                if ($block) {

                    $block->delete();
                    return '0';

                } else {

                    Block::create([
                        'user_id1' => $userID,
                        'user_id2' => $user_id,
                    ]);
                    return '1';
                }
            }

        }
    }

    public function my_blocks(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $following = Block::where('user_id1', $userID)
                ->select('user_id2')->get();
            return $following;
        }
    }

    public function my_block_list(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $blocks = Block::where('user_id1', $userID)->latest()->get();

            $blockData = array();

            foreach ($blocks as $block) {

                $userProfile = Sentinel::findUserByid($block->user_id2);
                $b = array();
                $b["user_id"] = $userProfile->id;
                $b["user_name"] = $userProfile->name;
                $b["username"] = $userProfile->username;
                $b["user_picture"] = Cloudder::show($userProfile->profile_picture_small, array());
                $carbon1 = Carbon::parse(($block->created_at))->diffForHumans();
                $b["time"] = $this->date_small($carbon1);
                array_push($blockData, $b);

            }
            return $blockData;

        }
    }


    public function otp(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $phone = $request->phone;

            $data = Otp::where([
                ['phone', $phone],
                ['status', 0],
                ['user_id', $userID],
            ])->orderBy('id', 'desc')->get();


            if ($totalsms = count($data)) {

                $carbon = Carbon::now()->diffInSeconds(Carbon::parse($data[0]->created_at));

                if ($totalsms >= 5) {

                    return 'Maximum Limit for this phone has been reached!';

                } else if ($carbon < 30) {

                    return 'true';


                    //TODO open otp box with response

                } else {
                    return $this->SendSms($userID, $request);
                }

            } else {
                return $this->SendSms($userID, $request);
            }

        }
    }


    public function SendSms($userID, $request)
    {
//        $randomOtp = rand(1000, 9999);
        $randomOtp = 1000;
//        $phoneNumber = $request->phone;
//
//        $curl = curl_init();
//
//        curl_setopt_array($curl, array(
//            CURLOPT_URL => "http://2factor.in/API/V1/17297c8b-f9e1-11e6-9462-00163ef91450/SMS/$phoneNumber/$randomOtp",
//            CURLOPT_RETURNTRANSFER => true,
//            CURLOPT_ENCODING => "",
//            CURLOPT_MAXREDIRS => 10,
//            CURLOPT_TIMEOUT => 30,
//            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//            CURLOPT_CUSTOMREQUEST => "GET",
//            CURLOPT_POSTFIELDS => "{}",
//        ));
//
//        curl_exec($curl);
//        curl_error($curl);
//
//        curl_close($curl);
//

        Otp::create([
            'phone' => $request->phone,
            'otp' => $randomOtp,
            'user_id' => $userID
        ]);
        return 'true';


    }

    private function setPhone($userID, $value, $value1)
    {

        $data = Otp::where('user_id', $userID)->orderBy('id', 'desc')->first();

        if (count($data)) {
            $userotp = $value;
            $sysotp = $data->otp;
            $status = $data->status;
            $carbon = Carbon::now()->diffInSeconds(Carbon::parse($data->created_at));
            $phone = $data->phone;
            if ($userotp == $sysotp && $status == 0) {

                if ($carbon <= 60) {

                    Otp::where('status', 0)
                        ->where('phone', $phone)
                        ->where('user_id', $userID)
                        ->where('otp', $sysotp)
                        ->update(['status' => 1]);

                    if ($value1 == 's')
                        $cradential = [
                            'phone' => $phone,
                            'status' => '2'
                        ];
                    else

                        $cradential = [
                            'phone' => $phone,
                        ];

                    DB::table('users')
                        ->where('id', $userID)
                        ->update($cradential);


                    return "1";

                } else {

                    return 'OTP is Expired !!';
                }
            } else {
                return 'Invalid OTP !!';
            }

        } else {
            return 'Invalid OTP!!';

        }
    }


    public function bigImage(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $request->user_id;
            $userProfile = Sentinel::findUserByid($userID);
            return Cloudder::show($userProfile->profile_picture_big, array());
        }
    }

    public function profileCountLists(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;
            $type = $request->type;
            $profileUser = $request->source_id;

            $Privacy = Privacy::where('user_id', $profileUser)->first();

            if ($type == 0) {


                $followers = Follow::where('user_id2', $profileUser)->latest()->paginate(10);
                $followData = array();

                foreach ($followers as $follower) {

                    $userprofile = Sentinel::findUserByid($follower->user_id1);

                    $follow = array();
                    $follow["user_id"] = $userprofile->id;
                    $follow["user_name"] = $userprofile->name;
                    $follow["username"] = $userprofile->username;
                    $follow["user_picture"] = Cloudder::show($userprofile->profile_picture_small, array());
                    $carbon1 = Carbon::parse(($follower->created_at))->diffForHumans();
                    $follow["time"] = $this->date_small($carbon1);
                    array_push($followData, $follow);

                }

                if ($Privacy) {

                    if ($Privacy->followers == 1 || $profileUser == $userID) {
                        return $followData;
                    }
                    return "-1";

                }

                return $followData;
            } else if ($type == 1) {


                $followers = Follow::where('user_id1', $profileUser)->latest()->paginate(10);
                $followData = array();

                foreach ($followers as $follower) {

                    $userprofile = Sentinel::findUserByid($follower->user_id2);

                    $follow = array();
                    $follow["user_id"] = $userprofile->id;
                    $follow["user_name"] = $userprofile->name;
                    $follow["username"] = $userprofile->username;
                    $follow["user_picture"] = Cloudder::show($userprofile->profile_picture_small, array());
                    $carbon1 = Carbon::parse(($follower->created_at))->diffForHumans();
                    $follow["time"] = $this->date_small($carbon1);
                    array_push($followData, $follow);

                }

                if ($Privacy) {

                    if ($Privacy->following == 1 || $profileUser == $userID) {
                        return $followData;
                    }
                    return "-1";

                }

                return $followData;

            } else if ($type == 2) {

                $faceData = array();

                $userprofile = Sentinel::findUserByid($profileUser);

                $facematchs = Facematch::where('user_id1', $profileUser)
                    ->orwhere('user_id2', $profileUser)
                    ->whereNotNull('user_ids')
                    ->latest()
                    ->paginate(10);

                foreach ($facematchs as $facematch) {
                    $userprofile1 = '';
                    if ($facematch->user_id1 == $profileUser)
                        $userprofile1 = Sentinel::findUserByid($facematch->user_id2);
                    else
                        $userprofile1 = Sentinel::findUserByid($facematch->user_id1);

                    $face = array();
                    $face["user_id"] = $userprofile1->id;
                    if ($facematch->user_ids == $request->user_id) {

                        $face["user_name"] = $userprofile->name . ' got an up vote against ' . $userprofile1->name;

                    } else {

                        $face["user_name"] = $userprofile->name . ' got a down vote against ' . $userprofile1->name;

                    }

                    $face["username"] = $userprofile1->username;
                    $face["user_picture"] = Cloudder::show($userprofile1->profile_picture_small, array());
                    $carbon1 = Carbon::parse(($facematch->created_at))->diffForHumans();
                    $face["time"] = $this->date_small($carbon1);
                    array_push($faceData, $face);


                }

                if ($Privacy) {

                    if ($Privacy->facematch == 1 || $profileUser == $userID) {
                        return $faceData;
                    }
                    return "-1";

                }

                return $faceData;

            }

        }
    }


    public function FaceMatchUpdate(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $user = $user->user_id;
            $facematch_id = $request->fid;
            $face_id = $request->userID;

            $facematch = Facematch::where('user_id', $user)
                ->where('id', $facematch_id)
                ->whereNull('user_ids')->first();


            $user_Selected = null;
            $user_not_Selected = null;

            if ($facematch->user_id1 == $face_id) {
                $user_Selected = $facematch->user_id1;
                $user_not_Selected = $facematch->user_id2;
            } elseif
            ($facematch->user_id2 == $face_id
            ) {
                $user_Selected = $facematch->user_id2;
                $user_not_Selected = $facematch->user_id1;
            } else {
                return $this->ajaxError('Invalid Request!! ');
            }
            $facematch->update(['user_ids' => $face_id]);


            $this->addNotification($user_Selected, $user_not_Selected, 2, 1);
            $this->addNotification($user_not_Selected, $user_Selected, 2, 0);
        }


    }


    public function profilePic(Request $request, $token)
    {


        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;


            $type_id = 2;
            $post_id = null;
            $postData = $request->metadata;

            $post1 = Post::create([
                'text' => $postData,
                'type_id' => $type_id,
                'user_id' => $userID
            ]);

            $post_id = $post1->id;

            try {

                Cloudder::upload($request->file('uploadfile'), null,
                    array(
                        "format" => "jpg", "crop" => "crop", "x" => 0, "y" => 0,
                        "width" => 500, "height" => 500, "crop" => "thumb",
                    ));
            } catch (\Exception $e) {
                return $this->ajaxError('Invalid Image format !');
            }

            $image2 = Cloudder::getResult();
            $image = $image2["public_id"];
            $image1 = $image2["height"];
            $image01 = $image2["width"];
            $image1 = $image1 / $image01;
            $value = $image . '-' . $image1;

            Post_data::create([
                'source' => $value,
                'type' => $type_id,
                'data' => 'Updated profile picture.',
                'post_id' => $post_id,

            ]);

            $pieces = explode("-", $value);
            $post['source'] = Cloudder::show($pieces[0], array());
            $post['height'] = $pieces[1];
            $post["id"] = $post_id;
            $post["user_id"] = $user->id;
            $post["text"] = $postData;

            try {

                Cloudder::upload(Cloudder::show($image, array()), null,
                    array(
                        "width" => 75, "height" => 75,
                    ));

            } catch (\Exception $e) {
                return $this->ajaxError('Invalid Image format !');
            }

            $image007 = Cloudder::getResult();
            $image008 = $image007["public_id"];

            DB::table('users')
                ->where('id', $userID)
                ->update([
                    'profile_picture_big' => $image,
                    'profile_picture_small' => $image008,
                ]);

            return Cloudder::show($image008, array());


        }
    }


    public function profileWall(Request $request, $token)
    {


        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;


            $type_id = 2;
            $post_id = null;
            $postData = $request->metadata;

            $post1 = Post::create([
                'text' => $postData,
                'type_id' => $type_id,
                'user_id' => $userID
            ]);

            $post_id = $post1->id;

            try {

                Cloudder::upload($request->file('uploadfile'), null,
                    array(
                        "format" => "jpg",
                        "width" => 1500, "height" => 1000, "crop" => "limit",
                    ));

            } catch (\Exception $e) {
                return $this->ajaxError('Invalid Image format !');
            }

            $image2 = Cloudder::getResult();
            $image = $image2["public_id"];
            $image1 = $image2["height"];
            $image01 = $image2["width"];
            $image1 = $image1 / $image01;
            $value = $image . '-' . $image1;

            Post_data::create([
                'source' => $value,
                'type' => $type_id,
                'data' => null,
                'post_id' => $post_id,

            ]);

            DB::table('users')
                ->where('id', $userID)
                ->update([
                    'wall_picture_big' => $image,
                    'wall_picture_small' => $image,
                ]);

            return Cloudder::show($image, array());


        }
    }


    public function addNotification($user_id, $source_id, $type, $activity_type)
    {

        Notification::create([
            'user_id' => $user_id,
            'source_id' => $source_id,
            'type' => $type,
            'activity_type' => $activity_type,
        ]);

    }

    public function removeNotification($user_id, $source_id, $type, $activity_type)
    {

        Notification::where([
            'user_id' => $user_id,
            'source_id' => $source_id,
            'type' => $type,
            'activity_type' => $activity_type,
        ])->delete();
    }


    public function suggestion(Request $request, $token)
    {

        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $userID = $user->user_id;

            $user = Sentinel::findUserByid($userID);
            $searchList = array();
            $searches = DB::table('users')
                ->where('id', '!=', $user->id)
                ->where('college_name_id', $user->college_name_id)
                ->orderBy(DB::raw('RAND()'))
                ->offset(0)
                ->limit(10)
                ->get();

            foreach ($searches as $search) {

                $search_user = array();
                $search_user["user_name"] = $search->name;
                $search_user["user_id"] = $search->id;
                if ($search->id == $user->id)
                    continue;
                $search_user["username"] = $search->username;
                $search_user["time"] = $search->intro;
                $search_user["user_picture"] = Cloudder::show($search->profile_picture_big, array());

                $isfollow = Follow::where('user_id2', $search->id)
                    ->where('user_id1', $user->id)
                    ->select('id')->count();

                if ($isfollow > 0)
                    continue;

                array_push($searchList, $search_user);
            }

            return $searchList;

        }

    }


    public function signUpPassword(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {
            $validator = Validator::make($request->all(), [
                'password' => 'bail|required|max:20|min:6',
            ]);

            if ($validator->fails())
                return $validator->messages()->get("password")[0];

            $validator = Validator::make($request->all(), [
                'confirm_password' => 'bail|required|max:20|min:6|same:password',

            ]);

            if ($validator->fails())
                return $validator->messages()->get("confirm_password")[0];

            $userID = $user->user_id;
            $new = $request->password;

            $user = Sentinel::findById($userID);


            Sentinel::update($user,
                array('password' => $new,
                    'status' => '1',)
            );

            return "1";

        }
    }


    public function signUpPasswordSkip(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $userID = $user->user_id;

            DB::table('users')
                ->where('id', $userID)
                ->update([
                    'status' => '2',
                ]);
            return "1";

        }
    }

    public function signUpGenderDob(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $userID = $user->user_id;
            $gender = $request->gender;
            $birthday_day = $request->birthday_day;
            $birthday_month = $request->birthday_month;
            $birthday_year = $request->birthday_year;

            $credentials = [
                'gender' => $gender,
                'birth_day' => $birthday_day,
                'birth_month' => $birthday_month,
                'birth_year' => $birthday_year,
                'status' => '3',
            ];

            DB::table('users')
                ->where('id', $userID)
                ->update($credentials);


            return "1";

        }
    }

    public function signUpProfilePicSkip(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $userID = $user->user_id;
            DB::table('users')
                ->where('id', $userID)
                ->update([
                    'status' => '4',
                ]);

return '1';
        }
    }

    public function signUpProfilePic(Request $request, $token)
    {
        $user = oAuth::where([
            'token' => $token,
        ])->first();

        if ($user) {

            $userID = $user->user_id;

            try {

                Cloudder::upload($request->file('uploadfile'), null,
                    array(
                        "format" => "jpg", "crop" => "crop", "x" => 0, "y" => 0,
                        "width" => 500, "height" => 500, "crop" => "thumb",
                    ));
            } catch (\Exception $e) {
                return $this->ajaxError('Invalid Image format !');
            }

            $image2 = Cloudder::getResult();
            $image = $image2["public_id"];

            try {

                Cloudder::upload(Cloudder::show($image, array()), null,
                    array(
                        "width" => 75, "height" => 75,
                    ));

            } catch (\Exception $e) {
                return $this->ajaxError('Invalid Image format !');
            }

            $image007 = Cloudder::getResult();
            $image008 = $image007["public_id"];

            DB::table('users')
                ->where('id', $userID)
                ->update([
                    'profile_picture_big' => $image,
                    'profile_picture_small' => $image008,
                ]);

            return Cloudder::show($image008, array());

        }
    }


}

// -----------------get data from PSIT-------------------------------//

function isUserFromPSIT($id, $password)
{
    $postdata = http_build_query(
        array(
            'id' => $id,
            'password' => $password,
        ));
    $opts = array('http' =>
        array(
            'method' => 'POST',
            'header' => 'Content-type: application/x-www-form-urlencoded',
            'content' => $postdata,
        ));
    $context = stream_context_create($opts);
    $result = file_get_contents('http://psit.in/psit/android/login_test.php', false, $context);
    return $result;
}


//

