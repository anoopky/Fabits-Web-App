@yield('body')
<script>chat_app_conversation_id =null;</script>