<div id="alert_message" class="navbar-fixed-top mt-1 col-xs-10 offset-xs-1 col-md-8 offset-md-2 p-0 z-1200"></div>
